function [BER_SF,BER_DCMA,BER_CSCMA_MPA,Size_remind,Complexity_SF,Complexity_DCMA,Complexity_SCMA]=SimulatorScenario0_IDD(SNR,N_h,S_SEP_sfscma,S_IDD_sfscma,S_IDD_dcma,S_IDD_scma,it_mpa_2Bao)
%%%This program was written by Benyamin Haghniaz to simulate Subcarrier-Flip SCMA to achieve full
%%%Diversity in final rate 1 bits/timeslot
%%%%This is the first scenario : SF-SCMA(4Bao), DCMA(Rate=1), SCMA(Rate=1,2Bao)
%%%IDD
%% Parameters
warning off
lanbda=1;

Cp_sfscma=2;
Constellation_sfscma=qammod(0:Cp_sfscma-1,Cp_sfscma)/sqrt(2);%%%constellation used in SF-SCMA
Cp_dcma=2;
Constellation_dcma=(qammod(0:Cp_dcma-1,Cp_dcma)/2); %%optimum constellation in DCMA rate=1

K=4; % total number of orthogonal resource elements (REs)
N=2;% number of utilized orthogonal resource elements (REs)
J=6; % number of users (UEs)
I_CB=K/N;
F_timeslot1=[1 0 0 1 0 1;0 1 0 1 1 0;1 0 1 0 1 0;0 1 1 0 0 1]; % factor graph in timeslot 1
F_timeslot2=abs([1 0 0 1 0 1;0 1 0 1 1 0;1 0 1 0 1 0;0 1 1 0 0 1]-1); % factor graph in timeslot 2
F_Total_2timeslot=[F_timeslot1;F_timeslot2]; %%Total factor graph
%%%%%%%%%%
Spreading1_timeslot1=[1 0; 0 0; 0 1; 0 0];
Spreading1_timeslot2=[0 0; 1 0; 0 0; 0 1];
Spreading1 =[Spreading1_timeslot1,Spreading1_timeslot2];
Spreading1_Total_2timeslot =[1 0 0 0; 0 0 0 0; 0 1 0 0;0 0 0 0; 0 0 0 0; 0 0 1 0; 0 0 0 0; 0 0 0 1];

Spreading2_timeslot1=[0 0; 1 0; 0 0; 0 1];
Spreading2_timeslot2=[1 0; 0 0; 0 1; 0 0];
Spreading2 =[Spreading2_timeslot1,Spreading2_timeslot2];
Spreading2_Total_2timeslot =[0 0 0 0; 1 0 0 0; 0 0 0 0;0 1 0 0; 0 0 1 0; 0 0 0 0; 0 0 0 1; 0 0 0 0];

Spreading3_timeslot1=[0 0; 0 0; 1 0; 0 1];
Spreading3_timeslot2=[1 0; 0 1; 0 0; 0 0];
Spreading3 =[Spreading3_timeslot1,Spreading3_timeslot2];
Spreading3_Total_2timeslot =[0 0 0 0; 0 0 0 0; 1 0 0 0;0 1 0 0; 0 0 1 0; 0 0 0 1; 0 0 0 0; 0 0 0 0];

Spreading4_timeslot1=[1 0; 0 1; 0 0; 0 0];
Spreading4_timeslot2=[0 0; 0 0; 1 0; 0 1];
Spreading4 =[Spreading4_timeslot1,Spreading4_timeslot2];
Spreading4_Total_2timeslot =[1 0 0 0; 0 1 0 0; 0 0 0 0;0 0 0 0; 0 0 0 0; 0 0 0 0; 0 0 1 0; 0 0 0 1];

Spreading5_timeslot1=[0 0; 1 0; 0 1; 0 0];
Spreading5_timeslot2=[1 0; 0 0; 0 0; 0 1];
Spreading5 =[Spreading5_timeslot1,Spreading5_timeslot2];
Spreading5_Total_2timeslot =[0 0 0 0; 1 0 0 0; 0 1 0 0;0 0 0 0; 0 0 1 0; 0 0 0 0; 0 0 0 0; 0 0 0 1];

Spreading6_timeslot1=[1 0; 0 0; 0 0; 0 1];
Spreading6_timeslot2=[0 0; 1 0; 0 1; 0 0];
Spreading6 =[Spreading6_timeslot1,Spreading6_timeslot2];
Spreading6_Total_2timeslot =[1 0 0 0; 0 0 0 0; 0 0 0 0;0 1 0 0; 0 0 0 0; 0 0 1 0; 0 0 0 1; 0 0 0 0];
%%%%codebook of SF-SCMA%%%%
k1=2;
Cube_2D=zeros(k1,2^k1);
for ii=1:2^k1
    Cube_2D(:,ii)=2*(double(fliplr(dec2bin(ii-1,k1)))-48)-1;
end
Cube_2D=Cube_2D/sqrt(2);%%normalized energy per time slot
Theta_4Bao=pi/4;
Psi_4Bao=pi/2;
R_4Bao=[cos(Theta_4Bao) exp(-1j*Psi_4Bao)*sin(Theta_4Bao);-exp(1j*Psi_4Bao)*sin(Theta_4Bao) cos(Theta_4Bao)];
Bao4=R_4Bao*Cube_2D;
Eave_4Bao=mean(sum(abs(Bao4).^2));%%%energy of each codeword
M_SFSCMA=4;%%%size of codebook
%%%% Codebook of DCMA %%%%%
U_Complex=qammod(0:1,2);
G=[ones(K,1)/2];
DCMA=G*U_Complex;
Eave_DCMA=mean(sum(abs(DCMA).^2));
M_DCMA=2;%%%size of codebook
%%%creating Codebooks of UEs in DCMA
X_DCMA=zeros(K,M_DCMA,J);
X_DCMA(:,:,1)=DCMA;
X_DCMA(:,:,2)=DCMA;
X_DCMA(:,:,3)=DCMA;
X_DCMA(:,:,4)=DCMA;
X_DCMA(:,:,5)=DCMA;
X_DCMA(:,:,6)=DCMA;
%%%creating Codebooks of UEs in CSCMA
M_CSCMA=2;%%%size of codebook
CodeWords_CSCMA = [qammod(0:1,2);qammod(0:1,2)]./sqrt(2);
Eave_CSCMA=mean(sum(abs(CodeWords_CSCMA).^2));
X_CSCMA=zeros(K,M_CSCMA,J);
X_CSCMA(:,:,1)=Spreading1(:,1:2)*CodeWords_CSCMA;
X_CSCMA(:,:,2)=Spreading2(:,1:2)*CodeWords_CSCMA;
X_CSCMA(:,:,3)=Spreading3(:,1:2)*CodeWords_CSCMA;
X_CSCMA(:,:,4)=Spreading4(:,1:2)*CodeWords_CSCMA;
X_CSCMA(:,:,5)=Spreading5(:,1:2)*CodeWords_CSCMA;
X_CSCMA(:,:,6)=Spreading6(:,1:2)*CodeWords_CSCMA;
%%%creating Codebooks of UEs in SF-SCMA
CodeWords_SFSCMA =Bao4;
X_SFSCMA1=zeros(K,M_SFSCMA,J);
X_SFSCMA1(:,:,1)=Spreading1(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA1(:,:,2)=Spreading2(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA1(:,:,3)=Spreading3(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA1(:,:,4)=Spreading4(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA1(:,:,5)=Spreading5(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA1(:,:,6)=Spreading6(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA2=zeros(K,M_SFSCMA,J);
X_SFSCMA2(:,:,1)=Spreading1(:,3:4)*CodeWords_SFSCMA;
X_SFSCMA2(:,:,2)=Spreading2(:,3:4)*CodeWords_SFSCMA;
X_SFSCMA2(:,:,3)=Spreading3(:,3:4)*CodeWords_SFSCMA;
X_SFSCMA2(:,:,4)=Spreading4(:,3:4)*CodeWords_SFSCMA;
X_SFSCMA2(:,:,5)=Spreading5(:,3:4)*CodeWords_SFSCMA;
X_SFSCMA2(:,:,6)=Spreading6(:,3:4)*CodeWords_SFSCMA;
%%%Codewords of SF-SCMA for a Total MPA%%%%%
X_Total=zeros(I_CB*K,M_SFSCMA,J);
X_Total(:,:,1)=Spreading1_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
X_Total(:,:,2)=Spreading2_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
X_Total(:,:,3)=Spreading3_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
X_Total(:,:,4)=Spreading4_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
X_Total(:,:,5)=Spreading5_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
X_Total(:,:,6)=Spreading6_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
Ec=mean(sum(abs(X_Total(:,:,1)).^2))/I_CB;%%the energy per timeslot is 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%
LM =1;%%bits per timeslot that is transmitted

BER_SEPD_SFSCMA=zeros(length(SNR),1);%%%SF-SCMA using SEP detector
BER_SR_SEP_SFSCMA =zeros(length(SNR),1);%%SF-SCMA size-reduction using SEP

BER_SD_DCMA=zeros(length(SNR),1);%%DCMA using SD detector

BER_MPA_SCMA=zeros(length(SNR),1);%%SCMA uisng MPA detector

Complexity_SEPD_SFSCMA_ave=zeros(length(SNR),1);
Complexity_SR_SEP_SFSCMA_ave=zeros(length(SNR),1);

Complexity_SD_DCMA_ave=zeros(length(SNR),1);


Complexity_MPA_CSCMA_ave=zeros(length(SNR),1);

UE_remind_SR_sfscma=zeros(length(SNR),1);

load('LDPC_BG1_8_2_3.mat')
% load('LDPC_BG1_10_5_6.mat')

H_ldpc=LDPC.H;
kbit=size(LDPC.G,1);
nbit=size(LDPC.G,2);
maxIterLDPC=20;
% LDPC encoder
hEnc = comm.LDPCEncoder('ParityCheckMatrix',sparse(H_ldpc));
% LDPC decoder
hDec = comm.LDPCDecoder('ParityCheckMatrix',hEnc.ParityCheckMatrix,'DecisionMethod','Soft decision','OutputValue','Whole codeword','MaximumIterationCount',maxIterLDPC,'IterationTerminationCondition','Parity check satisfied','NumIterationsOutputPort',true);
%% Monte-Carlo simulation
snr=10^(SNR/10);
noise_power = (Ec)/(snr);

Err_SEPD_SFSCMA=0;
Err_SR_SEP_SFSCMA=0;

Err_SD_DCMA=0;

Err_MPA_SCMA=0;

Complexity_SEP_SFSCMA=0;Complexity_SR_SEP_SFSCMA=0;%%complexity in SF-SCMA
Complexity_GSD_DCMA=0;%%complexity in DCMA
Complexity_MPA_CSCMA=0;%%complexity in SCMA

C_dcma=(1/12*(4^K)+1/6*(3^K));G_dcma= 1;
PEP_DCMA = min(C_dcma/(G_dcma*(snr^K)),0.1);
dp_min=1;C_sfscma=(1/12*(4^K)+1/6*(3^K));G_sfscma=(dp_min^2)^I_CB;
% PEP_sfscma = min(C_sfscma/(G_sfscma*(snr^K)),0.1);
% PEP_sfscma = min(1/(G_sfscma*(snr^K)),0.1);
% PEP_sfscma = 1/(G_sfscma*(snr^K));
% PEP_sfscma = 1*1/((1+(dp_min)*snr/4)^K)*0.5;%%% chernoff bound threshold
% PEP_sfscma=1/12*1/((1+(dp_min)*snr/4)^K)+1/6*1/((1+(dp_min)*snr/3)^K);%%% exact bound threshold
%%%%%%%%%%compound threshold1%%%%%%%%%%%%%%%%%
% if  SNR>=0 && SNR<=3
%     PEP_sfscma = 1.35*1/((1+(dp_min)*snr/4)^K)*0.5;
% else
%     PEP_sfscma = 1/((1+(dp_min)*snr/4)^K)*0.5;
% end
% %%%%%%%%%%compound threshold 2 %%%%%%%%%%%%%%%%%
if  SNR>=0 && SNR<=1
    PEP_sfscma = 2*(1/((1+(dp_min)*snr/4)^K)*0.5);
elseif SNR>=2 && SNR<=4
    PEP_sfscma = 1.35*(1/((1+(dp_min)*snr/4)^K)*0.5);
else
    PEP_sfscma = (1/((1+(dp_min)*snr/4)^K)*0.5);
end
% %%%%%%%%%%compound threshold3%%%%%%%%%%%%%%%%%
% if  SNR>=0 && SNR<=6
%     PEP_sfscma = 1.35*PEP_sfscma;
% else
%     PEP_sfscma = PEP_sfscma;
% end
for n_h=1:N_h
    H=((randn(K,J)+1i*randn(K,J))/sqrt(2)); %%%rayleigh fading channel (SFIC),quasi-static fading ,Indepnedent channel coefficient
    H_Total_SEPD_sfscma=[H;H];
    H_MIMO_DCMA=[diag(H(:,1))*ones(K,1),diag(H(:,2))*ones(K,1),diag(H(:,3))*ones(K,1),diag(H(:,4))*ones(K,1),diag(H(:,5))*ones(K,1),diag(H(:,6))*ones(K,1)];
    Q_DCMA=H_MIMO_DCMA'*H_MIMO_DCMA+lanbda*eye(size(H_MIMO_DCMA'*H_MIMO_DCMA));
    Hmad_DCMA=chol(Q_DCMA,'upper');    %%

    chIn=[];kbit_in=[];
    for jj=1:J
        kbit_in =[kbit_in, randi([0 1],kbit,1)];
        chIn = [chIn, step(hEnc,kbit_in(:,jj))];
    end

    out_SEPD_sfscma = zeros(size(kbit_in));
    out_SR_sfscma =zeros(size(kbit_in));
    out_GSD_dcma = zeros(size(kbit_in));
    out_scma = zeros(size(kbit_in));

    y_sfscma =zeros(I_CB*K,size(chIn,1)/(I_CB*LM));
    y_dcma=zeros(K,size(chIn,1)/(LM));
    y_scma=zeros(K,size(chIn,1)/(LM));

    %%%%%%%%%%%%%%Subcarrier Flip scma (SF-SCMA)%%%%%%%%%%%%%%
    for bb1=1:size(chIn,1)/(I_CB*LM)
        bits_information_SFSCMA=chIn((bb1-1)*I_CB*LM+1:bb1*I_CB*LM,:);
        codewords=[2^0 2^1]*bits_information_SFSCMA+1;%%00=1;10=2;01=3;11=4
        %%%%%%%%%%%%%%Subcarrier Flip scma (SF-SCMA)%%%%%%%%%%%%%%
        y_Total=[];
        for iiii=1:I_CB
            %%%%%% Fliping scma %%%%%%
            if mod(iiii,2) == 1
                X=X_SFSCMA1;
                H_MIMO_SCMA1 = [diag(H(:,1))*Spreading1_timeslot1*R_4Bao,diag(H(:,2))*Spreading2_timeslot1*R_4Bao,diag(H(:,3))*Spreading3_timeslot1*R_4Bao,diag(H(:,4))*Spreading4_timeslot1*R_4Bao,diag(H(:,5))*Spreading5_timeslot1*R_4Bao,diag(H(:,6))*Spreading6_timeslot1*R_4Bao];
            else
                X=X_SFSCMA2;
                H_MIMO_SCMA2 = [diag(H(:,1))*Spreading1_timeslot2*R_4Bao,diag(H(:,2))*Spreading2_timeslot2*R_4Bao,diag(H(:,3))*Spreading3_timeslot2*R_4Bao,diag(H(:,4))*Spreading4_timeslot2*R_4Bao,diag(H(:,5))*Spreading5_timeslot2*R_4Bao,diag(H(:,6))*Spreading6_timeslot2*R_4Bao];
            end
            x=[X(:,codewords(1),1),X(:,codewords(2),2),X(:,codewords(3),3),X(:,codewords(4),4),X(:,codewords(5),5),X(:,codewords(6),6)];%%x : transmitted codewords by ecah user
            TotalStates=H.*x;
            sig=sum(TotalStates,2); %% the codewords at each subcarrier are added
            y=sig+sqrt(noise_power)*(randn(K,1)+1i*randn(K,1))/sqrt(2); %%y : received signal at BS
            y_Total=[y_Total;y];
        end
        y_sfscma(:,bb1)=y_Total;
    end
    %%%%%%%%%%%sf-scma%%%%%%%%%%%%%%%%%
    LM_SFSCMA = log2(M_SFSCMA);
    Lambda_e_SEP_sfscma_final = zeros(size(chIn));
    Lambda_0_SEP_sfscma_final = zeros(size(chIn));
    Lambda_0_SEP_sfscma = zeros(LM_SFSCMA,J);
    Lambda_e_SEP_sfscma = zeros(LM_SFSCMA,J);
    poseterior_4_SR=zeros(J,size(CodeWords_SFSCMA,2),size(chIn,1)/(I_CB*LM));
    for iter_idd_sfscma=0:S_IDD_sfscma
        %%%%%%%%%%%%%%%IDD+SEP%%%%%%%%%%%%%%%%
        for bb1=1:size(chIn,1)/(I_CB*LM)
            pui_sep=zeros(J,M_SFSCMA);
            Lambda_0_SEP_sfscma = Lambda_0_SEP_sfscma_final((bb1-1)*LM_SFSCMA+1:bb1*LM_SFSCMA,:);
            %%%%%updating prior probability%%%%%%
            for jjj=1:size(Lambda_0_SEP_sfscma,2)
                pui_sep(jjj,:)=[max(min((1/(1+exp(-Lambda_0_SEP_sfscma(1,jjj)))),1-1e-12),1e-12)*max(min((1/(1+exp(-Lambda_0_SEP_sfscma(2,jjj)))),1-1e-12),1e-12),...
                    max(min((1/(1+exp(Lambda_0_SEP_sfscma(1,jjj)))),1-1e-12),1e-12)*max(min((1/(1+exp(-Lambda_0_SEP_sfscma(2,jjj)))),1-1e-12),1e-12),...
                    max(min((1/(1+exp(-Lambda_0_SEP_sfscma(1,jjj)))),1-1e-12),1e-12)*max(min((1/(1+exp(Lambda_0_SEP_sfscma(2,jjj)))),1-1e-12),1e-12),...
                    max(min((1/(1+exp(Lambda_0_SEP_sfscma(1,jjj)))),1-1e-12),1e-12)*max(min((1/(1+exp(Lambda_0_SEP_sfscma(2,jjj)))),1-1e-12),1e-12)];
                pui_sep(jjj,:)=pui_sep(jjj,:)/sum(pui_sep(jjj,:));
            end
            [posteriors_SEP_sfscma,Mea,Vari,Comp1]=SEPalg(X_Total,M_SFSCMA,F_Total_2timeslot,noise_power,y_sfscma(:,bb1),H_Total_SEPD_sfscma,1,S_SEP_sfscma,iter_idd_sfscma,pui_sep);
            Complexity_SEP_SFSCMA = Complexity_SEP_SFSCMA + Comp1;
            for jjj=1:J
                Lambda_e_SEP_sfscma(1,jjj)=log(sum(posteriors_SEP_sfscma(jjj,1:2:M_SFSCMA-1))/sum(posteriors_SEP_sfscma(jjj,2:2:M_SFSCMA)));
                Lambda_e_SEP_sfscma(2,jjj)=log(sum(posteriors_SEP_sfscma(jjj,1:M_SFSCMA/2))/sum(posteriors_SEP_sfscma(jjj,M_SFSCMA/2+1:M_SFSCMA)));
            end
            Lambda_e_SEP_sfscma_final ((bb1-1)*LM_SFSCMA+1:bb1*LM_SFSCMA,:)=Lambda_e_SEP_sfscma;
            poseterior_4_SR(:,:,bb1)=posteriors_SEP_sfscma;
            Mea_4_SR(:,:,bb1)=Mea;
            Vari_4_SR(:,:,bb1)=Vari;
        end

        for jjj=1:J
            [LLR_SEP_sfscma,~] = step(hDec, Lambda_e_SEP_sfscma_final(:,jjj));
            Lambda_0_SEP_sfscma_final(:,jjj)=LLR_SEP_sfscma-Lambda_e_SEP_sfscma_final(:,jjj);
            Lambda_0_SEP_sfscma_final(:,jjj) = max(min(Lambda_0_SEP_sfscma_final(:,jjj),500),-500) ;
            out_SEPD_sfscma(:,jjj)=double(LLR_SEP_sfscma(1:kbit)<0);
        end
    end
    Err_SEPD_SFSCMA = Err_SEPD_SFSCMA + biterr(out_SEPD_sfscma,kbit_in);
    % %%%%%%%%%%%%%%% IDD+SEP+SR %%%%%%%%%%%%%%%%
    Lambda_e_SEP_SR_final = Lambda_e_SEP_sfscma_final;
    if S_IDD_sfscma ~=0
        Lambda_0_SEP_SR_final = Lambda_0_SEP_sfscma_final/(2*N*J);
    else
        Lambda_0_SEP_SR_final =  zeros(size(chIn));
    end
    Lambda_0_SEP_SR = zeros(LM_SFSCMA,J);
    Lambda_e_SEP_SR = zeros(LM_SFSCMA,J);
    H_MIMO_equal=[H_MIMO_SCMA1;H_MIMO_SCMA2];
    if iter_idd_sfscma==S_IDD_sfscma
        for bb11=1:size(chIn,1)/(I_CB*LM)
            Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+(S_IDD_sfscma+1)*Comp1;
            Lambda_0_SEP_SR = Lambda_0_SEP_SR_final ((bb11-1)*LM_SFSCMA+1:bb11*LM_SFSCMA,:);
            Lambda_0_SEP_SR =Lambda_0_SEP_SR(:);
            Mea= Mea_4_SR(:,:,bb11);
            Vari= Vari_4_SR(:,:,bb11);
            uhat_SEP=[];
            for jj=1:J
                [~, m]=max(poseterior_4_SR(jj,:,bb11));
                uhat_SEP=[uhat_SEP;Cube_2D(:,m)];
            end
            for jj=1:J
                [Address,~]=find(abs(F_Total_2timeslot(:,jj))==1);
                muu=Mea(Address,jj);
                varr = Vari(Address,jj);
                sigma22(1,jj) =1/(1/(varr(1))+1/(varr(3)));
                mu2(1,jj) =sigma22(1,jj)*(muu(1)/varr(1)+muu(3)/varr(3));
                sigma22(2,jj) =1/(1/(varr(2))+1/(varr(4)));
                mu2(2,jj) =sigma22(2,jj)*(muu(2)/varr(2)+muu(4)/varr(4));
                MeanVector_sep(:,jj)=R_4Bao'*mu2(:,jj);
                VarVector_sep(:,jj)=real(diag(R_4Bao'*diag(sigma22(:,jj))*R_4Bao));
            end
            MeanVector_sep = real(MeanVector_sep);
            Index_validation_sep=abs(MeanVector_sep(:))./real(VarVector_sep(:))>(1/sqrt(2)^3)*log((1/PEP_sfscma)-1);
            Index_validation_sep_novel = sum(reshape(double(Index_validation_sep),N,J));
            Index_valid_SR_sep_novel=find(Index_validation_sep_novel==2);
            Index_remaind_SR_sep_novel=find(Index_validation_sep_novel~=2);
            %  Index_valid_SR_sep_novel=find(Index_validation_sep_novel~=0);
            % Index_remaind_SR_sep_novel=find(Index_validation_sep_novel==0);
            UUU =[2*Index_valid_SR_sep_novel-1;2*Index_valid_SR_sep_novel];
            VVV=[2*Index_remaind_SR_sep_novel-1;2*Index_remaind_SR_sep_novel];
            Index_valid_SR =UUU(:);
            Index_remind_SR = VVV(:);
            Index_validation_sep(Index_valid_SR)=1;
            Index_validation_sep(Index_remind_SR)=0;
            Index_valid_SR_sep=find(Index_validation_sep==1);
            Index_remind_SR_sep=find(Index_validation_sep==0);
            uhat_SEP_Confirmed=(uhat_SEP).*Index_validation_sep;

            UE_remind_SR_sfscma=UE_remind_SR_sfscma+length(Index_remaind_SR_sep_novel);
            %%%%%%%%%Size Reduction SD %%%%%
            if (isempty(Index_remaind_SR_sep_novel))
                Lambda_e_SEP_SR_final((bb11-1)*LM_SFSCMA+1:bb11*LM_SFSCMA,:)=Lambda_e_SEP_sfscma_final((bb11-1)*LM_SFSCMA+1:bb11*LM_SFSCMA,:);
            else
                Lambda_0_SEP_SR(Index_valid_SR)=[];
                [Index_valid_SEP_SR,~]=find(uhat_SEP_Confirmed~=0);
                [Index_remind_SEP_SR,~]=find(uhat_SEP_Confirmed==0);
                yr_sep=y_sfscma(:,bb11)-H_MIMO_equal(:,Index_valid_SEP_SR)*uhat_SEP_Confirmed(Index_valid_SEP_SR);
                Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+length(y_Total)+length(Index_valid_SEP_SR)*(size(H_MIMO_equal,1)/2)+length(Index_valid_SEP_SR);
                Hr_sep=H_MIMO_equal(:,Index_remind_SEP_SR);
                if size(Hr_sep,2)>size(Hr_sep,1)
                    G_1=Hr_sep(:,1:size(Hr_sep,1));
                    G_2=Hr_sep(:,size(Hr_sep,1)+1:size(Hr_sep,2));
                    z_=zeros(size(Hr_sep,2)-size(Hr_sep,1),size(Hr_sep,1));
                    I_=eye(size(Hr_sep,2)-size(Hr_sep,1),size(Hr_sep,2)-size(Hr_sep,1));
                    Hmad_SR =[G_1 G_2;z_ I_];
                    ymad_SR =[yr_sep;zeros(size(Hr_sep,2)-size(Hr_sep,1),1)];
                    % [Q, Hmad_SR_sep] = qr(Hmad_SR);
                    % Order = 1:size(Hmad_SR_sep,2);
                    [Q,Hmad_SR_sep,Order] = sqr(Hmad_SR);
                    ymad_SR_sep=Q'*ymad_SR;
                    Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+size(Q',1)*size(yr_sep,2)*(2*size(Q',2)-1);
                    TxRx_sfscma.Ntx = size(Hmad_SR_sep,2);
                    TxRx_sfscma.Constellations_norm = Constellation_sfscma;
                    TxRx_sfscma.Modulation_order = log2(Cp_sfscma);%%BPSK modulation
                    TxRx_sfscma.Detector.MaxLLR = 500;
                    TxRx_sfscma.Detector.Clipping ='exact';
                    [Lambda_e_SEP_SR,Comp55sep] = SISO_STS_SD(TxRx_sfscma,Hmad_SR_sep,ymad_SR_sep,Order,-Lambda_0_SEP_SR);
                    Lambda_e_SEP_SR = Lambda_e_SEP_SR/noise_power;
                    % Complexity_SR_SEP_SFSCMA = Complexity_SR_SEP_SFSCMA+numel(Lambda_e_SEP_SR);
                    Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+Comp55sep;

                else
                    % [Q, Hmad_SR_sep] = qr(Hr_sep);
                    % Order = 1:size(Hmad_SR_sep,2);
                    [Q,Hmad_SR_sep,Order] = sqr(Hr_sep);
                    ymad_SR_sep=Q'*yr_sep;
                    Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+size(Q',1)*size(yr_sep,2)*(2*size(Q',2)-1);
                    TxRx_sfscma.Ntx = size(Hmad_SR_sep,2);
                    TxRx_sfscma.Constellations_norm = Constellation_sfscma;
                    TxRx_sfscma.Modulation_order = log2(Cp_sfscma);%%BPSK modulation
                    TxRx_sfscma.Detector.MaxLLR = 500;
                    TxRx_sfscma.Detector.Clipping ='exact';
                    [Lambda_e_SEP_SR,Comp66sep] = SISO_STS_SD(TxRx_sfscma,Hmad_SR_sep,ymad_SR_sep,Order,-Lambda_0_SEP_SR);
                    Lambda_e_SEP_SR = Lambda_e_SEP_SR/noise_power;
                    % Complexity_SR_SEP_SFSCMA = Complexity_SR_SEP_SFSCMA+numel(Lambda_e_SEP_SR);
                    Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+Comp66sep;
                end
                Lambda_e_SEP_SR_final ((bb11-1)*LM_SFSCMA+1:bb11*LM_SFSCMA,Index_remaind_SR_sep_novel) = -reshape(Lambda_e_SEP_SR,2,[]);
            end
        end
        for jjj=1:J
            [LLR_SR_sfscma,~] = step(hDec, Lambda_e_SEP_SR_final(:,jjj));
            out_SR_sfscma(:,jjj)=double(LLR_SR_sfscma(1:kbit)<0);
        end
        Err_SR_SEP_SFSCMA=Err_SR_SEP_SFSCMA+biterr(out_SR_sfscma,kbit_in);
    end
    %%%%%%%%%%%%%%%%%%%%%DCMA%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Lambda_e_GSD_dcma_final = zeros(size(chIn));
    Lambda_0_GSD_dcma_final = zeros(size(chIn));
    Lambda_0_GSD_dcma = zeros(LM,J);
    Lambda_e_GSD_dcma = zeros(LM,J);
    for bb2=1:size(chIn,1)/(LM)
        bits_information_DCMA=chIn((bb2-1)*LM+1:bb2*LM,:);
        codewords=2.^bits_information_DCMA;%%0=1;1=2;
        x_DCMA=[X_DCMA(:,codewords(1),1),X_DCMA(:,codewords(2),2),X_DCMA(:,codewords(3),3),X_DCMA(:,codewords(4),4),X_DCMA(:,codewords(5),5),X_DCMA(:,codewords(6),6)];                %%x : transmitted codewords by ecah user
        TotalStates_DCMA=H.*x_DCMA;
        Sig_DCMA=sum(TotalStates_DCMA,2); %% the codewords at each subcarrier are added
        y_dcma(:,bb2)=Sig_DCMA+sqrt(noise_power)*(randn(K,1)+1i*randn(K,1))/sqrt(2); %%y : received signal at BS antenna 1
    end
    for iter_idd=0:S_IDD_dcma
        for bb2=1:size(chIn,1)/(LM)
            %%%%%%%%%%%%%%%IDD+GSD%%%%%%%%%%%%%%%%
            Lambda_0_GSD_dcma = Lambda_0_GSD_dcma_final((bb2-1)*LM+1:bb2*LM,:);
            ymad_DCMA=(H_MIMO_DCMA*inv(Hmad_DCMA))'*y_dcma(:,bb2);
            Complexity_GSD_DCMA=Complexity_GSD_DCMA+(2*size(y_dcma,1)-1);
            TxRx_dcma.Ntx = J;
            TxRx_dcma.Constellations_norm = Constellation_dcma;
            TxRx_dcma.Modulation_order = log2(Cp_dcma);%%BPSK modulation
            TxRx_dcma.Detector.MaxLLR = 500;
            TxRx_dcma.Detector.Clipping ='exact';
            Order = 1:J;
            [Lambda_e_GSD_dcma,Comp_sd] = SISO_STS_SD(TxRx_dcma,Hmad_DCMA,ymad_DCMA,Order,-Lambda_0_GSD_dcma.');
            Lambda_e_GSD_dcma = Lambda_e_GSD_dcma/noise_power;
            % Complexity_GSD_DCMA =Complexity_GSD_DCMA+numel(Lambda_e_GSD_dcma);
            Complexity_GSD_DCMA = Complexity_GSD_DCMA + Comp_sd;
            Lambda_e_GSD_dcma_final ((bb2-1)*LM+1:bb2*LM,:)=-Lambda_e_GSD_dcma.';
        end

        for jjj=1:J
            [LLR_GSD_DCMA,~] = step(hDec,Lambda_e_GSD_dcma_final(:,jjj));
            Lambda_0_GSD_dcma_final(:,jjj)=LLR_GSD_DCMA-Lambda_e_GSD_dcma_final(:,jjj);
            Lambda_0_GSD_dcma_final(:,jjj) = max(min(Lambda_0_GSD_dcma_final(:,jjj),500),-500) ;
            out_GSD_dcma(:,jjj)=double(LLR_GSD_DCMA(1:kbit)<0);
        end
        
    end
    Err_SD_DCMA = Err_SD_DCMA + biterr(out_GSD_dcma,kbit_in);
    %%%%%%%%%%%%%%%%%%%%original scma%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Lambda_e_MPA_scma_final = zeros(size(chIn));
    Lambda_0_MPA_scma_final = zeros(size(chIn));
    Lambda_0_MPA_scma = zeros(LM,J);
    Lambda_e_MPA_scma = zeros(LM,J);
    for bb3=1:size(chIn,1)/(LM)
        bits_information_scma=chIn((bb3-1)*LM+1:bb3*LM,:);
        codewords_cscma=2.^bits_information_scma;%%0=1;1=2;
        x_CSCMA=[X_CSCMA(:,codewords_cscma(1),1),X_CSCMA(:,codewords_cscma(2),2),X_CSCMA(:,codewords_cscma(3),3),X_CSCMA(:,codewords_cscma(4),4),X_CSCMA(:,codewords_cscma(5),5),X_CSCMA(:,codewords_cscma(6),6)];                %%x : transmitted codewords by ecah user
        TotalStates_SCMA=H.*x_CSCMA;
        Sig_SCMA=sum(TotalStates_SCMA,2); %% the codewords at each subcarrier are added
        y_scma(:,bb3)=Sig_SCMA+sqrt(noise_power)*(randn(K,1)+1i*randn(K,1))/sqrt(2); %%y : received signal at BS antenna 1
    end
    for iter_idd=0:S_IDD_scma
        for bb3=1:size(chIn,1)/(LM)
            %%%%%%%%%%%%%%%IDD+MPA%%%%%%%%%%%%%%%%
            pui_mpa_scma=zeros(J,M_CSCMA);
            Lambda_0_MPA_scma = Lambda_0_MPA_scma_final((bb3-1)*LM+1:bb3*LM,:);
            %%%%%updating prior probability%%%%%%
            for jjj=1:size(Lambda_0_MPA_scma,2)
                pui_mpa_scma(jjj,:)=[max(min((1/(1+exp(-Lambda_0_MPA_scma(1,jjj)))),1-1e-12),1e-12),...
                    max(min((1/(1+exp(Lambda_0_MPA_scma(1,jjj)))),1-1e-12),1e-12)];
                pui_mpa_scma(jjj,:)=pui_mpa_scma(jjj,:)/sum(pui_mpa_scma(jjj,:));
            end
            [posteriors_MPA_scma,~,Comp4]=MPA_detector_priori_corrected(y_scma(:,bb3),X_CSCMA,H,F_timeslot1,K,J,M_CSCMA,pui_mpa_scma,sqrt(noise_power),it_mpa_2Bao,1);
            Complexity_MPA_CSCMA = Complexity_MPA_CSCMA + Comp4;
            for jjj=1:J
                Lambda_e_MPA_scma(1,jjj)=log(sum(posteriors_MPA_scma(jjj,M_CSCMA-1))/sum(posteriors_MPA_scma(jjj,M_CSCMA)));
            end
            Lambda_e_MPA_scma_final ((bb3-1)*LM+1:bb3*LM,:)=Lambda_e_MPA_scma;
        end

        for jjj=1:J
            [LLR_scma,~] = step(hDec, Lambda_e_MPA_scma_final(:,jjj));
            Lambda_0_MPA_scma_final(:,jjj)=LLR_scma-Lambda_e_MPA_scma_final(:,jjj);
            Lambda_0_MPA_scma_final(:,jjj) = max(min(Lambda_0_MPA_scma_final(:,jjj),50),-50) ;
            out_scma(:,jjj)=double(LLR_scma(1:kbit)<0);
        end
    end
    Err_MPA_SCMA = Err_MPA_SCMA + biterr(out_scma,kbit_in);
end
Complexity_GSD_DCMA = Complexity_GSD_DCMA +2*size(H_MIMO_DCMA',1)^2*size(H_MIMO_DCMA',2)-size(H_MIMO_DCMA',1)^2+size(Q_DCMA,1);
Complexity_GSD_DCMA = Complexity_GSD_DCMA +4/3*(length(Q_DCMA)^3);
Complexity_GSD_DCMA=Complexity_GSD_DCMA+length(Hmad_DCMA)^3+size(H_MIMO_DCMA,1)*size(Hmad_DCMA,2)*(2*size(H_MIMO_DCMA,2)-1);
Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+1*(12*(12^2))+6*(10*(10^2))+15*(8*(8^2))+20*(8*(6^2))+15*(8*(4^2))+6*(8*(2^2));%%size(Hr_sep,1)*(size(Hr_sep,2)^2);

BER_SEPD_SFSCMA=Err_SEPD_SFSCMA/(J*N_h*kbit);
BER_SR_SEP_SFSCMA =Err_SR_SEP_SFSCMA/(J*N_h*kbit);

BER_GSD_DCMA=Err_SD_DCMA/(J*N_h*kbit);

BER_MPA_SCMA=Err_MPA_SCMA/(J*N_h*kbit);

UE_remind_SR_sfscma=UE_remind_SR_sfscma/(N_h*(size(chIn,1)/(I_CB*LM)));

%%%%%%%comlexity per information bit
Complexity_SEPD_SFSCMA_ave=Complexity_SEP_SFSCMA/N_h/(J*kbit);
Complexity_SR_SEP_SFSCMA_ave=Complexity_SR_SEP_SFSCMA/(N_h*J*kbit);

Complexity_GSD_DCMA_ave=Complexity_GSD_DCMA/(N_h*J*kbit);

Complexity_MPA_CSCMA_ave=Complexity_MPA_CSCMA/(N_h*J*kbit);
%%%%%%%%%%%%%%%%%%%%output%%%%%%%%%%
BER_SF=[BER_SEPD_SFSCMA,BER_SR_SEP_SFSCMA];
BER_DCMA=[BER_GSD_DCMA];
BER_CSCMA_MPA=BER_MPA_SCMA;
Size_remind=[UE_remind_SR_sfscma];
Complexity_SF=[Complexity_SEPD_SFSCMA_ave,Complexity_SR_SEP_SFSCMA_ave];
Complexity_DCMA=[Complexity_GSD_DCMA_ave];
Complexity_SCMA=Complexity_MPA_CSCMA_ave;
end