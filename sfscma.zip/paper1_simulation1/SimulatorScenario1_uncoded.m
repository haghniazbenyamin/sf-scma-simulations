function [BER_SF,BER_DCMA,BER_CSCMA_MPA,Size_remind,Complexity_SF,Complexity_DCMA,Complexity_SCMA]=SimulatorScenario1_uncoded(SNR,N_h,S_BEP_dcma,S_BEP_sfscma,S_SEP_sfscma,it_mpa_4Bao,it_mpa_Total)
%%%THis program was written by Benyamin Haghniaz to simulate Subcarrier-Flip SCMA to achieve full
%%%diversity in final rate 2 bits/timeslot
%%%%This is the first scenario : SF-SCMA(Rate=2,16Bao), DCMA(Rate=2), SCMA(Rate=2,4Bao)
%% Parameters
N_b=250;%%the number of data blocks, in each block the channel is invariant
complexFlag=1;
pui_ldpc=[];
lanbda=1;

Cp1=4;
Constellation1=qammod(0:Cp1-1,Cp1)/2;%%%constellation used in SF-SCMA
Cp2=4;
Constellation2=qammod(0:Cp2-1,Cp2)/(2*sqrt(2)); %%optimum constellation in DCMA rate=2

K=4; % total number of orthogonal resource elements (REs)
N=2;% number of utilized orthogonal resource elements (REs)
J=6; % number of users (UEs)
I_CB=K/N;
F_timeslot1=[1 0 0 1 0 1;0 1 0 1 1 0;1 0 1 0 1 0;0 1 1 0 0 1]; % factor graph in timeslot 1
F_timeslot2=abs([1 0 0 1 0 1;0 1 0 1 1 0;1 0 1 0 1 0;0 1 1 0 0 1]-1); % factor graph in timeslot 2
F_Total_2timeslot=[F_timeslot1;F_timeslot2]; %%Total factor graph
%%%%%%%%%%
Spreading1_timeslot1=[1 0; 0 0; 0 1; 0 0];
Spreading1_timeslot2=[0 0; 1 0; 0 0; 0 1];
Spreading1 =[Spreading1_timeslot1,Spreading1_timeslot2];
Spreading1_Total_2timeslot =[1 0 0 0; 0 0 0 0; 0 1 0 0;0 0 0 0; 0 0 0 0; 0 0 1 0; 0 0 0 0; 0 0 0 1];

Spreading2_timeslot1=[0 0; 1 0; 0 0; 0 1];
Spreading2_timeslot2=[1 0; 0 0; 0 1; 0 0];
Spreading2 =[Spreading2_timeslot1,Spreading2_timeslot2];
Spreading2_Total_2timeslot =[0 0 0 0; 1 0 0 0; 0 0 0 0;0 1 0 0; 0 0 1 0; 0 0 0 0; 0 0 0 1; 0 0 0 0];

Spreading3_timeslot1=[0 0; 0 0; 1 0; 0 1];
Spreading3_timeslot2=[1 0; 0 1; 0 0; 0 0];
Spreading3 =[Spreading3_timeslot1,Spreading3_timeslot2];
Spreading3_Total_2timeslot =[0 0 0 0; 0 0 0 0; 1 0 0 0;0 1 0 0; 0 0 1 0; 0 0 0 1; 0 0 0 0; 0 0 0 0];

Spreading4_timeslot1=[1 0; 0 1; 0 0; 0 0];
Spreading4_timeslot2=[0 0; 0 0; 1 0; 0 1];
Spreading4 =[Spreading4_timeslot1,Spreading4_timeslot2];
Spreading4_Total_2timeslot =[1 0 0 0; 0 1 0 0; 0 0 0 0;0 0 0 0; 0 0 0 0; 0 0 0 0; 0 0 1 0; 0 0 0 1];

Spreading5_timeslot1=[0 0; 1 0; 0 1; 0 0];
Spreading5_timeslot2=[1 0; 0 0; 0 0; 0 1];
Spreading5 =[Spreading5_timeslot1,Spreading5_timeslot2];
Spreading5_Total_2timeslot =[0 0 0 0; 1 0 0 0; 0 1 0 0;0 0 0 0; 0 0 1 0; 0 0 0 0; 0 0 0 0; 0 0 0 1];

Spreading6_timeslot1=[1 0; 0 0; 0 0; 0 1];
Spreading6_timeslot2=[0 0; 1 0; 0 1; 0 0];
Spreading6 =[Spreading6_timeslot1,Spreading6_timeslot2];
Spreading6_Total_2timeslot =[1 0 0 0; 0 0 0 0; 0 0 0 0;0 1 0 0; 0 0 0 0; 0 0 1 0; 0 0 0 1; 0 0 0 0];
%%%%codebook of SCMA%%%%
k1=2;
Cube_2D=zeros(k1,2^k1);
for ii=1:2^k1
    Cube_2D(:,ii)=2*(double(fliplr(dec2bin(ii-1,k1)))-48)-1;
end
Cube_2D=Cube_2D/sqrt(2);%%normalized energy per time slot
Theta_4Bao=pi/4;
Psi_4Bao=pi/2;
R_4Bao=[cos(Theta_4Bao) exp(-1j*Psi_4Bao)*sin(Theta_4Bao);-exp(1j*Psi_4Bao)*sin(Theta_4Bao) cos(Theta_4Bao)];
Bao4=R_4Bao*Cube_2D;
Eave_4Bao=mean(sum(abs(Bao4).^2));%%%energy of each codeword
M_SCMA=4;%%%size of codebook
%%%%Codebook of SF-SCMA%%%%%
k2=4;
Cube_4D=zeros(k2,2^k2);
for ii=1:2^k2
    Cube_4D(:,ii)=2*(double(fliplr(dec2bin(ii-1,k2)))-48)-1;
end
Cube_4D_complex=[Cube_4D(1,:)+1j*Cube_4D(2,:);Cube_4D(3,:)+1j*Cube_4D(4,:)]/2;
Theta_16Bao=pi/4;
Psi_16Bao=pi/3;
R_16Bao=[cos(Theta_16Bao) exp(-1j*Psi_16Bao)*sin(Theta_16Bao);-exp(1j*Psi_16Bao)*sin(Theta_16Bao) cos(Theta_16Bao)];
Bao16=R_16Bao*Cube_4D_complex;
Eave_16Bao=mean(sum(abs(Bao16).^2));
M_SFSCMA=16;%%%size of codebook
%%%%Codebook of DCMA%%%%%
U_Complex=Cube_2D(1,:)+1j*Cube_2D(2,:);
G=[ones(K,1)/2,1j*ones(K,1)/2];
DCMA=G*Cube_2D;
Eave_DCMA=mean(sum(abs(DCMA).^2));
M_DCMA=4;%%%size of codebook
%%%creating Codebooks of UEs in DCMA
X_DCMA=zeros(K,M_DCMA,J);
X_DCMA(:,:,1)=DCMA;
X_DCMA(:,:,2)=DCMA;
X_DCMA(:,:,3)=DCMA;
X_DCMA(:,:,4)=DCMA;
X_DCMA(:,:,5)=DCMA;
X_DCMA(:,:,6)=DCMA;
%%%creating Codebooks of UEs in SCMA
CodeWords_SCMA = Bao4;
X_SCMA=zeros(K,M_SCMA,J);
X_SCMA(:,:,1)=Spreading1(:,1:2)*CodeWords_SCMA;
X_SCMA(:,:,2)=Spreading2(:,1:2)*CodeWords_SCMA;
X_SCMA(:,:,3)=Spreading3(:,1:2)*CodeWords_SCMA;
X_SCMA(:,:,4)=Spreading4(:,1:2)*CodeWords_SCMA;
X_SCMA(:,:,5)=Spreading5(:,1:2)*CodeWords_SCMA;
X_SCMA(:,:,6)=Spreading6(:,1:2)*CodeWords_SCMA;
%%%creating Codebooks of UEs in SF-SCMA
CodeWords_SFSCMA =Bao16;
X_SFSCMA1=zeros(K,M_SFSCMA,J);
X_SFSCMA1(:,:,1)=Spreading1(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA1(:,:,2)=Spreading2(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA1(:,:,3)=Spreading3(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA1(:,:,4)=Spreading4(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA1(:,:,5)=Spreading5(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA1(:,:,6)=Spreading6(:,1:2)*CodeWords_SFSCMA;
X_SFSCMA2=zeros(K,M_SFSCMA,J);
X_SFSCMA2(:,:,1)=Spreading1(:,3:4)*CodeWords_SFSCMA;
X_SFSCMA2(:,:,2)=Spreading2(:,3:4)*CodeWords_SFSCMA;
X_SFSCMA2(:,:,3)=Spreading3(:,3:4)*CodeWords_SFSCMA;
X_SFSCMA2(:,:,4)=Spreading4(:,3:4)*CodeWords_SFSCMA;
X_SFSCMA2(:,:,5)=Spreading5(:,3:4)*CodeWords_SFSCMA;
X_SFSCMA2(:,:,6)=Spreading6(:,3:4)*CodeWords_SFSCMA;
%%%Codewords of SF-SCMA for a Total MPA%%%%%
X_Total=zeros(I_CB*K,M_SFSCMA,J);
X_Total(:,:,1)=Spreading1_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
X_Total(:,:,2)=Spreading2_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
X_Total(:,:,3)=Spreading3_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
X_Total(:,:,4)=Spreading4_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
X_Total(:,:,5)=Spreading5_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
X_Total(:,:,6)=Spreading6_Total_2timeslot*[CodeWords_SFSCMA;CodeWords_SFSCMA];
Ec=mean(sum(abs(X_Total(:,:,1)).^2))/I_CB;%%the energy per timeslot is 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%
LM =2;%%bits per timeslot that is transmitted

BER_BEPD_SFSCMA=zeros(length(SNR),1);%%%SF-SCMA using BEP detector
BER_SEPD_SFSCMA=zeros(length(SNR),1);%%%SF-SCMA using SEP detector
BER_MPA_SFSCMA=zeros(length(SNR),1);%%SF-SCMA using MPA detector
BER_SR_BEP_SFSCMA =zeros(length(SNR),1);%%SF-SCMA size-reduction using BEP
BER_SR_SEP_SFSCMA =zeros(length(SNR),1);%%SF-SCMA size-reduction using SEP

BER_SD_DCMA=zeros(length(SNR),1);%%DCMA using SD detector
BER_BEPD_DCMA=zeros(length(SNR),1);%%DCMA using BEP detector
BER_SR_DCMA =zeros(length(SNR),1);%%DCMA using SR-SD using BEP

BER_MPA_SCMA=zeros(length(SNR),1);%%SCMA uisng MPA detector

Complexity_BEPD_SFSCMA_ave=zeros(length(SNR),1);
Complexity_SEPD_SFSCMA_ave=zeros(length(SNR),1);
Complexity_MPA_SFSCMA_ave=zeros(length(SNR),1);
Complexity_SR_BEP_SFSCMA_ave=zeros(length(SNR),1);
Complexity_SR_SEP_SFSCMA_ave=zeros(length(SNR),1);

Complexity_BEPD_DCMA_ave=zeros(length(SNR),1);
Complexity_SD_DCMA_ave=zeros(length(SNR),1);
Complexity_SR_DCMA_ave=zeros(length(SNR),1);


Complexity_MPA_CSCMA_ave=zeros(length(SNR),1);

Size_remind_SR_BEP_sfscma=zeros(length(SNR),1);
Size_remind_SR_SEP_sfscma=zeros(length(SNR),1);
Size_remind_SR_dcma=zeros(length(SNR),1);
%% Monte-Carlo simulation
snr=10^(SNR/10);
noise_power = (Ec)/(snr);

Err_BEPD_SFSCMA=0;
Err_SEPD_SFSCMA=0;
Err_MPA_SFSCMA =0;
Err_SR_BEP_SFSCMA=0;
Err_SR_SEP_SFSCMA=0;

Err_BEPD_DCMA=0;
Err_SD_DCMA=0;
Err_SR_DCMA=0;

Err_MPA_SCMA=0;

Complexity_BEP_SFSCMA=0;Complexity_SEP_SFSCMA=0;Complexity_MPA_SFSCMA=0;Complexity_SR_BEP_SFSCMA=0;Complexity_SR_SEP_SFSCMA=0;%%complexity in SF-SCMA
Complexity_BEPD_DCMA=0; Complexity_SD_DCMA=0;Complexity_SR_dcma=0;%%complexity in DCMA
Complexity_MPA_CSCMA=0;%%complexity in SCMA

C_dcma=(1/12*(4^K)+1/6*(3^K));G_dcma= 0.0625;
PEP_DCMA = min(C_dcma/(G_dcma*(snr^K)),0.1);

dp_min=0.5;C_sfscma=(1/12*(4^K)+1/6*(3^K));G_sfscma=(dp_min^2)^I_CB;
PEP_sfscma = min(C_sfscma/(G_sfscma*(snr^K)),0.1);

counter1=zeros(N_h,1);

for n_h=1:N_h
    H=((randn(K,J)+1i*randn(K,J))/sqrt(2)); %%%rayleigh fading channel (SFIC),quasi-static fading ,Indepnedent channel coefficient
    %%
    for n_b=1:N_b
        %%%%%%%%%%%%%%Subcarrier Flip scma (SF-SCMA)%%%%%%%%%%%%%%
        bits_information_SFSCMA=(randi([0 1],I_CB*LM,J));
        codewords=[2^0 2^1 2^2 2^3]*bits_information_SFSCMA+1;%%0000=1;1000=2;0100=3;...;1111=16
        y_Total=[];
        for iiii=1:I_CB
            %%%%%% Fliping scma %%%%%%
            if mod(iiii,2) == 1
                X=X_SFSCMA1;
                F=F_timeslot1;
                H_MIMO_SCMA1 = [diag(H(:,1))*Spreading1_timeslot1*R_16Bao,diag(H(:,2))*Spreading2_timeslot1*R_16Bao,diag(H(:,3))*Spreading3_timeslot1*R_16Bao,diag(H(:,4))*Spreading4_timeslot1*R_16Bao,diag(H(:,5))*Spreading5_timeslot1*R_16Bao,diag(H(:,6))*Spreading6_timeslot1*R_16Bao];
            else
                X=X_SFSCMA2;
                F=F_timeslot2;
                H_MIMO_SCMA2 = [diag(H(:,1))*Spreading1_timeslot2*R_16Bao,diag(H(:,2))*Spreading2_timeslot2*R_16Bao,diag(H(:,3))*Spreading3_timeslot2*R_16Bao,diag(H(:,4))*Spreading4_timeslot2*R_16Bao,diag(H(:,5))*Spreading5_timeslot2*R_16Bao,diag(H(:,6))*Spreading6_timeslot2*R_16Bao];
            end
            x=[X(:,codewords(1),1),X(:,codewords(2),2),X(:,codewords(3),3),X(:,codewords(4),4),X(:,codewords(5),5),X(:,codewords(6),6)];%%x : transmitted codewords by ecah user
            TotalStates=H.*x;
            sig=sum(TotalStates,2); %% the codewords at each subcarrier are added
            y=sig+sqrt(noise_power)*(randn(K,1)+1i*randn(K,1))/sqrt(2); %%y : received signal at BS
            y_Total=[y_Total;y];
        end
        %%%%BEPD
        H_Total_BEPD=[H_MIMO_SCMA1;H_MIMO_SCMA2];
        [uhat_BEPD,~,~,~,Comp1]=BEPalg(Constellation1,complexFlag,sqrt(noise_power),y_Total,H_Total_BEPD,pui_ldpc,S_BEP_sfscma);
        Complexity_BEP_SFSCMA=Complexity_BEP_SFSCMA+Comp1;
        uhat_BEPD_final= reshape(uhat_BEPD,2,J);
        codeword_BEPD=zeros(J,1);
        for d=1:J
            CriteriaBEPD=sum(abs(uhat_BEPD_final(:,d)-Cube_4D_complex).^2);
            m_BEPD=find(CriteriaBEPD==min(CriteriaBEPD));
            codeword_BEPD(d)=m_BEPD;
        end
        bits_hat_BEPD=flipud((double(dec2bin(codeword_BEPD-1,I_CB*LM))-48)');
        Err_BEPD_SFSCMA=Err_BEPD_SFSCMA+sum(bits_information_SFSCMA(:)~=bits_hat_BEPD(:));
        %%%%SEP
        H_Total_SEP =[H;H];
        [posteriors_SEP,~,~,Comp_sep]=SEPalg(X_Total,M_SFSCMA,F_Total_2timeslot,noise_power,y_Total,H_Total_SEP,1,S_SEP_sfscma,[]);
        Complexity_SEP_SFSCMA=Complexity_SEP_SFSCMA+Comp_sep;
        codewords_SEP=zeros(J,1);
        for jj=1:J
            [~,cc]=max(posteriors_SEP(jj,:));
            codewords_SEP(jj,1)=cc;
        end
        bits_hat_SEPD=flipud((double(dec2bin(codewords_SEP-1,I_CB*LM))-48)');
        Err_SEPD_SFSCMA=Err_SEPD_SFSCMA+sum(bits_information_SFSCMA(:)~=bits_hat_SEPD(:));
        %%%%MPA
%         H_Total_MPA=repmat(H,I_CB,1);%%slow fading for 2 time slots (SFIC)
%         [xp,~,Comp2]=MPA_detector_priori_corrected(y_Total,X_Total,H_Total_MPA,F_Total_2timeslot,K,J,M_SFSCMA,(1/M_SFSCMA)*ones(J,M_SFSCMA),sqrt(noise_power),it_mpa_Total,I_CB);
%         Complexity_MPA_SFSCMA=Complexity_MPA_SFSCMA+Comp2;
%         codeword_MPA=zeros(J,1);
%         for jj=1:J
%             [~, m]=max(xp(jj,:));
%             codeword_MPA(jj)=m;
%         end
%         bits_hat_MPA=flipud((double(dec2bin(codeword_MPA-1,I_CB*LM))-48)');
%         Err_MPA_SFSCMA=Err_MPA_SFSCMA+sum(bits_information_SFSCMA(:)~=bits_hat_MPA(:));
        %%%%%%%%%%%%%%%%% SF-SCMA SR-SD using BEP %%%%%%%%%%%%%%%%
        H_Total_BEPD=[H_MIMO_SCMA1;H_MIMO_SCMA2];
        [uhat_EP,~,nu_qiii,var_qiii,Comp11]=BEPalg(Constellation1,complexFlag,sqrt(noise_power),y_Total,H_Total_BEPD,pui_ldpc,S_BEP_sfscma);
        Complexity_SR_BEP_SFSCMA =Complexity_SR_BEP_SFSCMA+1*Comp11;
        var_qiii=real(var_qiii);
        nu_qii_aux=conj(nu_qiii);
        %     Index_validation= max(real(nu_qii_aux*Constellation1)./var_qiii,[],2) > 1/4*log((1/PEP_sfscma)-1);
        CONST_bep=(2*real(nu_qii_aux*Constellation1)./var_qiii);
        CONST_bep(CONST_bep >= 100) =100;
        CONST_bep(CONST_bep <= -100) =-100;
        Reliability=max(real(nu_qii_aux*Constellation1)./var_qiii,[],2);
        Index_validation=Reliability>(1/2*log((1-PEP_sfscma))+1/2*log(sum(exp(CONST_bep),2)));
        %     Index_validation_bep_novel = sum(reshape(double(Index_validation),N,J));
        %     Index_valid_SR_bep_novel=find(Index_validation_bep_novel~=0);
        %     Index_remaind_SR_bep_novel=find(Index_validation_bep_novel==0);
        %     UUU =[2*Index_valid_SR_bep_novel-1;2*Index_valid_SR_bep_novel];
        %     VVV=[2*Index_remaind_SR_bep_novel-1;2*Index_remaind_SR_bep_novel];
        %     Index_valid_SR =UUU(:);
        %     Index_remind_SR = VVV(:);
        %     Index_validation(Index_valid_SR)=1;
        %     Index_validation(Index_remind_SR)=0;
        Index_valid_SR=find(Index_validation==1);
        Index_remind_SR=find(Index_validation==0);
        uhat_EPD_Confirmed=(uhat_EP).*Index_validation;
        Size_remind_SR_BEP_sfscma=Size_remind_SR_BEP_sfscma+length(Index_remind_SR);
        uhat_SD_SR_EPD = uhat_EPD_Confirmed;
        %%%%%%%%%Size Reduction SD %%%%%
        if (uhat_EPD_Confirmed~=zeros(I_CB*J,1))
            uhat_SD_SR_EPD=uhat_EPD_Confirmed;
        else
            [Index_valid_EPD_SR,~]=find(uhat_EPD_Confirmed~=0);
            [Index_remind_EPD_SR,~]=find(uhat_EPD_Confirmed==0);
            %         if length(Index_remind_EPD_SR)>size(y_Total,1)
            %             [~,Index_remind_EPD_SR_sorted] =sort(Reliability(Index_remind_EPD_SR),'ascend');
            %             [~,Index_remind_EPD_SR_sorted] =sort(sum(abs(H_Total_BEPD(:,Index_remind_EPD_SR)).^2),'ascend');
            %             Index_remind_EPD_SR =Index_remind_SR(Index_remind_EPD_SR_sorted(1:size(y_Total,1)));
            %             Index_valid_EPD_SR =[Index_valid_EPD_SR;Index_remind_SR(Index_remind_EPD_SR_sorted(size(y_Total,1)+1:end))];
            %             uhat_SD_SR_EPD(Index_valid_EPD_SR)=uhat_EP(Index_valid_EPD_SR);
            %         end
            yr=y_Total-H_Total_BEPD(:,Index_valid_EPD_SR)*uhat_EPD_Confirmed(Index_valid_EPD_SR);
            Complexity_SR_BEP_SFSCMA=Complexity_SR_BEP_SFSCMA+length(y_Total)+(size(H_Total_BEPD(:,Index_valid_EPD_SR),1)/2)*(size(H_Total_BEPD(:,Index_valid_EPD_SR),2))+(size(H_Total_BEPD(:,Index_valid_EPD_SR),1));
            Hr=H_Total_BEPD(:,Index_remind_EPD_SR);
            if size(Hr,2)>size(Hr,1)
                Q_SR=Hr'*Hr+lanbda*eye(size(Hr'*Hr));
                Complexity_SR_BEP_SFSCMA=Complexity_SR_BEP_SFSCMA+2*size(Hr',1)^2*size(Hr',2)-size(Hr',1)^2+size(Q_SR,1);
                Hmad_SR=chol(Q_SR,'upper');
                Complexity_SR_BEP_SFSCMA = Complexity_SR_BEP_SFSCMA +4/3*length(Q_SR)^3;
                ymad_SR=(Hr*inv(Hmad_SR))'*yr;
                Complexity_SR_BEP_SFSCMA=Complexity_SR_BEP_SFSCMA+(2*size(yr,1)-1);%%complexity of Tikh
                Radius_SD_SR=realmax;%norm(ymad_SR-Hmad_SR*uhat_EP(Index_remind_EPD_SR),2)^2+1e-3; %realmax;%;
                [uhat_SR_remind,Comp55]= sphere_dec_Tikh(Hmad_SR,ymad_SR,Radius_SD_SR,Cp1,Constellation1);
                Complexity_SR_BEP_SFSCMA=Complexity_SR_BEP_SFSCMA+1*Comp55;
%                 G_1_bep=Hr(:,1:size(Hr,1));
%                 G_2_bep=Hr(:,size(Hr,1)+1:size(Hr,2));
%                 z_bep=zeros(size(Hr,2)-size(Hr,1),size(Hr,1));
%                 I_bep=eye(size(Hr,2)-size(Hr,1),size(Hr,2)-size(Hr,1));
%                 Hmad_SR =[G_1_bep G_2_bep;z_bep I_bep];
%                 ymad_SR =[yr;zeros(size(Hr,2)-size(Hr,1),1)];
%                 Radius_SD_SR=norm(ymad_SR-Hmad_SR*uhat_EP(Index_remind_EPD_SR),2)^2+1e-3; %realmax;%;
%                 [uhat_SR_remind,Comp55]= sphere_dec_namazi(Hmad_SR,ymad_SR,Radius_SD_SR,Cp1,Constellation1);
%                 Complexity_SR_BEP_SFSCMA=Complexity_SR_BEP_SFSCMA+1*Comp55;
%                 counter1(n_h)=-1;
            else
                Hmad_SR=Hr;
                ymad_SR=yr;
                Radius_SD_SR=realmax;%norm(ymad_SR-Hmad_SR*uhat_EP(Index_remind_EPD_SR),2)^2+1e-3;%realmax;%;
                [uhat_SR_remind,Comp66]= sphere_dec_namazi(Hmad_SR,ymad_SR,Radius_SD_SR,Cp1,Constellation1);
                Complexity_SR_BEP_SFSCMA=Complexity_SR_BEP_SFSCMA+1*Comp66;
%                 counter1(n_h)=+1;
            end
            uhat_SD_SR_EPD(Index_remind_EPD_SR)=uhat_SR_remind;
        end
        uhat_SD_SR_EPD_final= reshape(uhat_SD_SR_EPD,2,J);
        codeword_SD_SR_EPD=zeros(J,1);
        for d=1:J
            CriteriaSD_SR_EPD=sum(abs(uhat_SD_SR_EPD_final(:,d)-Cube_4D_complex).^2);
            m_SD_SR_EPD=find(CriteriaSD_SR_EPD==min(CriteriaSD_SR_EPD));
            codeword_SD_SR_EPD(d,1)=m_SD_SR_EPD;
        end
        bits_hat_SR=flipud((double(dec2bin(codeword_SD_SR_EPD-1,I_CB*LM))-48)');
        Err_SR_BEP_SFSCMA=Err_SR_BEP_SFSCMA+sum(bits_information_SFSCMA(:)~=bits_hat_SR(:));
        %%%%%%%%%%%%%%%%%%%%%%%%%% SF-SCMA SR-SD using SEP%%%%%%%%%
        H_Total_SEP =[H;H];
        [posteriors_SEP,Mea,Vari,Comp_sep1]=SEPalg(X_Total,M_SFSCMA,F_Total_2timeslot,noise_power,y_Total,H_Total_SEP,1,S_SEP_sfscma,[]);
        Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+Comp_sep1;
        uhat_SEP=[];
        for jj=1:J
            [~, m]=max(posteriors_SEP(jj,:));
            uhat_SEP=[uhat_SEP;Cube_4D_complex(:,m)];
        end
        MeanVector_sep=[];VarVector_sep=[];
        for jj=1:J
            [Address,~]=find(abs(F_Total_2timeslot(:,jj))==1);
            muu=Mea(Address,jj);
            varr = Vari(Address,jj);
            sigma22(1,jj) =1/(1/(varr(1))+1/(varr(3)));
            mu2(1,jj) =sigma22(1,jj)*(muu(1)/varr(1)+muu(3)/varr(3));
            sigma22(2,jj) =1/(1/(varr(2))+1/(varr(4)));
            mu2(2,jj) =sigma22(2,jj)*(muu(2)/varr(2)+muu(4)/varr(4));
            MeanVector_sep(:,jj)=R_16Bao'*mu2(:,jj);
            VarVector_sep(:,jj)=real(diag(R_16Bao'*diag(sigma22(:,jj))*R_16Bao));
        end
        %     for jj=1:J
        %         [Address,~]=find(abs(F_Total_2timeslot(:,jj))==1);
        %         muu=Mea(Address,jj);
        %         varr = Vari(Address,jj);
        %         sigma22(1,jj) =1/(1/(varr(1)/2)+1/(varr(3)/2));
        %         mu2(1,jj) =sigma22(1,jj)*(real(muu(1))/(varr(1)/2)+real(muu(3))/(varr(3)/2));
        %         sigma22(2,jj) =1/(1/(varr(2)/2)+1/(varr(4)/2));
        %         mu2(2,jj) =sigma22(2,jj)*(real(muu(2))/(varr(2)/2)+real(muu(4))/(varr(4)/2));
        %             sigma22_p(1,jj) =1/(1/(varr(1)/2)+1/(varr(3)/2));
        %         mu2_p(1,jj) =sigma22_p(1,jj)*(imag(muu(1))/(varr(1)/2)+imag(muu(3))/(varr(3)/2));
        %         sigma22_p(2,jj) =1/(1/(varr(2)/2)+1/(varr(4)/2));
        %         mu2(2,jj) =sigma22_p(2,jj)*(imag(muu(2))/(varr(2)/2)+imag(muu(4))/(varr(4)/2));
        %         MeanVector_sep(:,jj)=R_16Bao'*mu2(:,jj);
        %         VarVector_sep(:,jj)=real(diag(R_16Bao'*diag(sigma22(:,jj))*R_16Bao));
        %     end
        %                         for jj=1:J
        %                     [Address,~]=find(abs(F_Total_2timeslot(:,jj))==1);
        %                             muu=reshape(Mea(Address,jj),2,2);
        %                             varr = reshape(Vari(Address,jj),2,2);
        %                             [M,I]=min(varr,[],2);
        %                             MeanVector_sep(:,jj)=R_16Bao'*[muu(1,I(1));muu(2,I(2))];
        %                             VarVector_sep(:,jj)=real(diag(R_16Bao'*diag([varr(1,I(1));varr(2,I(2))])*R_16Bao));
        %                         end
        %         for jj=1:J
        %             [Address,~]=find(abs(F_Total_2timeslot(:,jj))==1);
        %             muu=reshape(Mea(Address,jj),2,2);
        %             varr = reshape(Vari(Address,jj),2,2);
        %             MeanVector_sep(:,jj)=R_16Bao'*mean(muu,2);
        %             VarVector_sep(:,jj)=real(diag(R_16Bao'*diag(mean(varr,2))*R_16Bao));
        %         end
        VarVector_sep=real(VarVector_sep(:));
        MeanVector_sep_aux=conj(MeanVector_sep(:));
        CONST=(2*real(MeanVector_sep_aux*Constellation1)./VarVector_sep);
        CONST(CONST >= 100) =100;
        CONST(CONST <= -100) =-100;
        Index_validation_sep=max(real(MeanVector_sep_aux*Constellation1)./VarVector_sep,[],2)>(1/2*log((1-PEP_sfscma))+1/2*log(sum(exp(CONST),2)));
        %     Index_validation_sep=max(real(MeanVector_sep_aux*Constellation1)./VarVector_sep,[],2)>(1/2*log((1-PEP_sfscma))+1/2*log(sum(exp((2*real(MeanVector_sep_aux*Constellation1)./VarVector_sep)),2)));
        %     Index_validation_sep= max(real(MeanVector_sep_aux*Constellation1)./VarVector_sep,[],2) > 1/4*log((1/PEP_sfscma)-1);
        %     Index_validation_sep_novel = sum(reshape(double(Index_validation_sep),N,J));
        %     Index_valid_SR_sep_novel=find(Index_validation_sep_novel~=0);
        %     Index_remaind_SR_sep_novel=find(Index_validation_sep_novel==0);
        %     UUU =[2*Index_valid_SR_sep_novel-1;2*Index_valid_SR_sep_novel];
        %     VVV=[2*Index_remaind_SR_sep_novel-1;2*Index_remaind_SR_sep_novel];
        %     Index_valid_SR_sep =UUU(:);
        %     Index_remind_SR_sep = VVV(:);
        %     Index_validation_sep(Index_valid_SR_sep)=1;
        %     Index_validation_sep(Index_remind_SR_sep)=0;
        Index_valid_SR_sep=find(Index_validation_sep==1);
        Index_remind_SR_sep=find(Index_validation_sep==0);
        uhat_SEP_Confirmed=(uhat_SEP).*Index_validation_sep;
        Size_remind_SR_SEP_sfscma=Size_remind_SR_SEP_sfscma+length(Index_remind_SR_sep);
        uhat_SD_SR_SEP=uhat_SEP_Confirmed;
        %%%%%%%%%Size Reduction SD %%%%%
        if (uhat_SEP_Confirmed~=zeros(I_CB*J,1))
            uhat_SD_SR_SEP=uhat_SEP_Confirmed;
        else
            [Index_valid_SEP_SR,~]=find(uhat_SEP_Confirmed~=0);
            [Index_remind_SEP_SR,~]=find(uhat_SEP_Confirmed==0);
            yr_sep=y_Total-H_Total_BEPD(:,Index_valid_SEP_SR)*uhat_SEP_Confirmed(Index_valid_SEP_SR);
            Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+length(y_Total)+size(H_Total_BEPD(:,Index_valid_SEP_SR),1)*(2*size(H_Total_BEPD(:,Index_valid_SEP_SR),2)-1);
            Hr_sep=H_Total_BEPD(:,Index_remind_SEP_SR);
            if size(Hr_sep,2)>size(Hr_sep,1)
                %             Q_SR_sep=Hr_sep'*Hr_sep+lanbda*eye(size(Hr_sep'*Hr_sep));
                %             Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+2*size(Hr_sep',1)^2*size(Hr_sep',2)-size(Hr_sep',1)^2+size(Q_SR_sep,1);
                %             Hmad_SR_sep=chol(Q_SR_sep,'upper');
                %             Complexity_SR_SEP_SFSCMA = Complexity_SR_SEP_SFSCMA +4/3*length(Q_SR_sep)^3;
                %             ymad_SR_sep=(Hr_sep*inv(Hmad_SR_sep))'*yr_sep;
                %             Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+length(Hmad_SR_sep)^3+size(Hr_sep,1)*size(Hmad_SR_sep,2)*(2*size(Hr_sep,2)-1)+size((Hr_sep*inv(Hmad_SR_sep))',1)*(2*size(yr_sep,1)-1);%%complexity of Tikh
                G_1=Hr_sep(:,1:size(Hr_sep,1));
                G_2=Hr_sep(:,size(Hr_sep,1)+1:size(Hr_sep,2));
                z_=zeros(size(Hr_sep,2)-size(Hr_sep,1),size(Hr_sep,1));
                I_=eye(size(Hr_sep,2)-size(Hr_sep,1),size(Hr_sep,2)-size(Hr_sep,1));
                Hmad_SR_sep =[G_1 G_2;z_ I_];
                ymad_SR_sep =[yr_sep;zeros(size(Hr_sep,2)-size(Hr_sep,1),1)];
                Radius_SD_SR_sep=norm(ymad_SR_sep-Hmad_SR_sep*(uhat_SEP(Index_remind_SR_sep)),2)^2+1e-3;
                %             [uhat_SR_remind_sep,Comp55sep]= sphere_dec_Tikh(Hmad_SR_sep,ymad_SR_sep,Radius_SD_SR_sep,Cp1,Constellation1);
                [uhat_SR_remind_sep,Comp55sep]= sphere_dec_namazi(Hmad_SR_sep,ymad_SR_sep,Radius_SD_SR_sep,Cp1,Constellation1);
                Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+Comp55sep;
            else
                Hmad_SR_sep=Hr_sep;
                ymad_SR_sep=yr_sep;
                Radius_SD_SR_sep=norm(ymad_SR_sep-Hmad_SR_sep*(uhat_SEP(Index_remind_SR_sep)),2)^2+1e-3;
                [uhat_SR_remind_sep,Comp66sep]= sphere_dec_namazi(Hmad_SR_sep,ymad_SR_sep,Radius_SD_SR_sep,Cp1,Constellation1);
                Complexity_SR_SEP_SFSCMA=Complexity_SR_SEP_SFSCMA+Comp66sep;
            end
            uhat_SD_SR_SEP(Index_remind_SEP_SR)=uhat_SR_remind_sep;
        end
        uhat_SD_SR_BEP_final= reshape(uhat_SD_SR_SEP,2,J);
        codeword_SD_SR_SEPD=zeros(J,1);
        for d=1:J
            CriteriaSD_SR_SEPD=sum(abs(uhat_SD_SR_BEP_final(:,d)-Cube_4D_complex).^2);
            m_SD_SR_SEPD=find(CriteriaSD_SR_SEPD==min(CriteriaSD_SR_SEPD));
            codeword_SD_SR_SEPD(d,1)=m_SD_SR_SEPD;
        end
        bits_hat_SR_SEP=flipud((double(dec2bin(codeword_SD_SR_SEPD-1,I_CB*LM))-48)');
        Err_SR_SEP_SFSCMA=Err_SR_SEP_SFSCMA+sum(bits_information_SFSCMA(:)~=bits_hat_SR_SEP(:));
        %%%%%%%%%%%%%%%%%%%%%DCMA%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        bits_information_DCMA=(randi([0 1],LM,J));
        H_MIMO_DCMA=[diag(H(:,1))*ones(K,1),diag(H(:,2))*ones(K,1),diag(H(:,3))*ones(K,1),diag(H(:,4))*ones(K,1),diag(H(:,5))*ones(K,1),diag(H(:,6))*ones(K,1)];
        codewords=[2^0 2^1]*bits_information_DCMA+1;%%00=1;10=2;01=3;11=4
        x_DCMA=[X_DCMA(:,codewords(1),1),X_DCMA(:,codewords(2),2),X_DCMA(:,codewords(3),3),X_DCMA(:,codewords(4),4),X_DCMA(:,codewords(5),5),X_DCMA(:,codewords(6),6)];                %%x : transmitted codewords by ecah user
        TotalStates_DCMA=H.*x_DCMA;
        Sig_DCMA=sum(TotalStates_DCMA,2); %% the codewords at each subcarrier are added
        y_DCMA=Sig_DCMA+sqrt(noise_power)*(randn(K,1)+1i*randn(K,1))/sqrt(2); %%y : received signal at BS antenna 1
        %%%%EPD
        [uhat_EPD_DCMA,~,~,~,Comp]=BEPalg(Constellation2,complexFlag,sqrt(noise_power),y_DCMA,H_MIMO_DCMA,pui_ldpc,S_BEP_dcma);
        Complexity_BEPD_DCMA = Complexity_BEPD_DCMA +Comp;
        codeword_EPD_DCMA=zeros(J,1);
        for d=1:J
            CriteriaEPD_DCMA=(abs(2*uhat_EPD_DCMA(d)-U_Complex).^2);
            m_EPD_DCMA=find(CriteriaEPD_DCMA==min(CriteriaEPD_DCMA));
            codeword_EPD_DCMA(d)=m_EPD_DCMA;
        end
        bits_hat_BEPD=flipud((double(dec2bin(codeword_EPD_DCMA-1,LM))-48)');
        Err_BEPD_DCMA= Err_BEPD_DCMA+sum(bits_hat_BEPD(:)~=bits_information_DCMA(:));
        %%%%SD
        Q_DCMA=H_MIMO_DCMA'*H_MIMO_DCMA+lanbda*eye(size(H_MIMO_DCMA'*H_MIMO_DCMA));
        Hmad_DCMA=chol(Q_DCMA,'upper');
        ymad_DCMA=(H_MIMO_DCMA*inv(Hmad_DCMA))'*y_DCMA;
        Complexity_SD_DCMA=Complexity_SD_DCMA+(2*size(y_DCMA,1)-1);
        Radius_SD_DCMA=realmax;%norm(ymad_DCMA-Hmad_DCMA*uhat_EPD_DCMA,2)^2+1e-3;
        [uhat_SD_DCMA,Comp_sd]= sphere_dec_Tikh(Hmad_DCMA,ymad_DCMA,Radius_SD_DCMA,Cp2,Constellation2);
        Complexity_SD_DCMA = Complexity_SD_DCMA + Comp_sd;
        codeword_SD_DCMA=zeros(J,1);
        for d=1:J
            CriteriaSD_DCMA=(abs(2*uhat_SD_DCMA(d)-U_Complex).^2);
            m_SD_DCMA=find(CriteriaSD_DCMA==min(CriteriaSD_DCMA));
            codeword_SD_DCMA(d)=m_SD_DCMA;
        end
        bits_hat_SD=flipud((double(dec2bin(codeword_SD_DCMA-1,LM))-48)');
        Err_SD_DCMA=Err_SD_DCMA+sum(bits_hat_SD(:)~=bits_information_DCMA(:));
        %%%%SR-SD
        [uhat_EP_dcma,~,Nu,Var,Comp00]=BEPalg(Constellation2,complexFlag,sqrt(noise_power),y_DCMA,H_MIMO_DCMA,pui_ldpc,S_BEP_dcma);
        Complexity_SR_dcma =Complexity_SR_dcma+1*Comp00;
        Var=real(Var);
        Nu_aux = conj(Nu);
        %         Index_validation_dcma=max(real(Nu_aux*Constellation2)./Var,[],2)>1/4*log((1/PEP_DCMA)-1);
        CONSTT=(2*real(Nu_aux*Constellation2)./Var);
        CONSTT(CONSTT >= 100) =100;
        CONSTT(CONSTT <= -100) =-100;
        Index_validation_dcma=max(real(Nu_aux*Constellation2)./Var,[],2)>1/2*log((1-PEP_DCMA))+1/2*log(sum(exp(CONSTT),2));
        Index_validation_SR_dcma=find(Index_validation_dcma==1);
        Index_remind_SR_dcma=find(Index_validation_dcma==0);
        uhat_EPD_Confirmed_dcma=(uhat_EP_dcma).*Index_validation_dcma;
        Size_remind_SR_dcma=Size_remind_SR_dcma+length(Index_remind_SR_dcma);
        uhat_SD_SR_EPD_dcma=uhat_EPD_Confirmed_dcma;
        %%%%%%%%%Size Reduction SD %%%%%
        if (uhat_EPD_Confirmed_dcma~=zeros(J,1))
            uhat_SD_SR_EPD_dcma=uhat_EPD_Confirmed_dcma;
        else
            [Index_valid_EPD_SR_dcma,~]=find(uhat_EPD_Confirmed_dcma~=0);
            [Index_remind_EPD_SR_dcma,~]=find(uhat_EPD_Confirmed_dcma==0);
            yr_dcma=y_DCMA-H_MIMO_DCMA(:,Index_valid_EPD_SR_dcma)*uhat_EPD_Confirmed_dcma(Index_valid_EPD_SR_dcma);
            Complexity_SR_dcma=Complexity_SR_dcma+length(y_DCMA)+size(H_MIMO_DCMA(:,Index_valid_EPD_SR_dcma),1)*(2*size(H_MIMO_DCMA(:,Index_valid_EPD_SR_dcma),2)-1);
            Hr_dcma=H_MIMO_DCMA(:,Index_remind_EPD_SR_dcma);
            if size(Hr_dcma,2)>size(Hr_dcma,1)
                Q_SR_dcma=Hr_dcma'*Hr_dcma+lanbda*eye(size(Hr_dcma'*Hr_dcma));
                Complexity_SR_dcma=Complexity_SR_dcma+2*size(Hr_dcma',1)^2*size(Hr_dcma',2)-size(Hr_dcma',1)^2+size(Q_SR_dcma,1);
                Hmad_SR_dcma=chol(Q_SR_dcma,'upper');
                Complexity_SR_dcma = Complexity_SR_dcma +4/3*length(Q_SR_dcma)^3;
                ymad_SR_dcma=(Hr_dcma*inv(Hmad_SR_dcma))'*yr_dcma;
                Complexity_SR_dcma=Complexity_SR_dcma+(2*size(yr_dcma,1)-1);%%complexity of Tikh
                Radius_SD_SR_dcma=norm(ymad_SR_dcma-Hmad_SR_dcma*uhat_EP_dcma(Index_remind_SR_dcma),2)^2+1e-3;
                [uhat_SR_remind_dcma,Comp555]= sphere_dec_Tikh(Hmad_SR_dcma,ymad_SR_dcma,Radius_SD_SR_dcma,Cp2,Constellation2);
                Complexity_SR_dcma=Complexity_SR_dcma+Comp555;
            else
                Hmad_SR_dcma=Hr_dcma;
                ymad_SR_dcma=yr_dcma;
                Radius_SD_SR_dcma=norm(ymad_SR_dcma-Hmad_SR_dcma*uhat_EP_dcma(Index_remind_SR_dcma),2)^2+1e-3;
                [uhat_SR_remind_dcma,Comp666]= sphere_dec_namazi(Hmad_SR_dcma,ymad_SR_dcma,Radius_SD_SR_dcma,Cp2,Constellation2);
                Complexity_SR_dcma=Complexity_SR_dcma+Comp666;
            end
            uhat_SD_SR_EPD_dcma(Index_remind_EPD_SR_dcma)=uhat_SR_remind_dcma;
        end
        codeword_SD_SR_dcma=zeros(J,1);
        for d=1:J
            CriteriaSD_SR_EPD_dcma=(abs(2*uhat_SD_SR_EPD_dcma(d)-U_Complex).^2);
            m_SD_SR_EPD_dcma=find(CriteriaSD_SR_EPD_dcma==min(CriteriaSD_SR_EPD_dcma));
            codeword_SD_SR_dcma(d,1)=m_SD_SR_EPD_dcma;
        end
        bits_hat_SR_dcma=flipud((double(dec2bin(codeword_SD_SR_dcma-1,LM))-48)');
        Err_SR_DCMA=Err_SR_DCMA+sum(bits_information_DCMA(:)~=bits_hat_SR_dcma(:));
        %%%%%%%%%%%%%%%%%%%%original scma%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        bits_information_scma=(randi([0 1],LM,J));
        codewords=[2^0 2^1]*bits_information_scma+1;%%00=1;10=2;01=3;11=4
        x_SCMA=[X_SCMA(:,codewords(1),1),X_SCMA(:,codewords(2),2),X_SCMA(:,codewords(3),3),X_SCMA(:,codewords(4),4),X_SCMA(:,codewords(5),5),X_SCMA(:,codewords(6),6)];                %%x : transmitted codewords by ecah user
        TotalStates_SCMA=H.*x_SCMA;
        Sig_SCMA=sum(TotalStates_SCMA,2); %% the codewords at each subcarrier are added
        y_SCMA=Sig_SCMA+sqrt(noise_power)*(randn(K,1)+1i*randn(K,1))/sqrt(2); %%y : received signal at BS antenna 1
        Priori_codewords=(1/M_SCMA)*ones(J,M_SCMA);%%priori probability of codewords in input of detector
        [xp,~,Comp_scma]=MPA_detector_priori_corrected(y_SCMA,X_SCMA,H,F_timeslot1,K,J,M_SCMA,Priori_codewords,sqrt(noise_power),it_mpa_4Bao,1);
        Complexity_MPA_CSCMA = Complexity_MPA_CSCMA + Comp_scma;
        codeword_scma=zeros(J,1);
        for jj=1:J
            [~, m]=max(xp(jj,:));
            codeword_scma(jj)=m;
        end
        bits_hat_scma=flipud((double(dec2bin(codeword_scma-1,LM))-48)');
        Err_MPA_SCMA= Err_MPA_SCMA+sum(bits_hat_scma(:)~=bits_information_scma(:));
    end
    Complexity_BEP_SFSCMA =Complexity_BEP_SFSCMA +length(H_Total_BEPD'*H_Total_BEPD)^3+(size(H_Total_BEPD',1)*size(H_Total_BEPD,2))*(2*size(H_Total_BEPD',2)-1)+numel(H_Total_BEPD'*H_Total_BEPD)+length(H_Total_BEPD'*H_Total_BEPD);
    Complexity_SR_BEP_SFSCMA =Complexity_SR_BEP_SFSCMA +length(H_Total_BEPD'*H_Total_BEPD)^3+(size(H_Total_BEPD',1)*size(H_Total_BEPD,2))*(2*size(H_Total_BEPD',2)-1)+numel(H_Total_BEPD'*H_Total_BEPD)+length(H_Total_BEPD'*H_Total_BEPD);
    Complexity_BEPD_DCMA=Complexity_BEPD_DCMA+length(H_MIMO_DCMA'*H_MIMO_DCMA)^3+(size(H_MIMO_DCMA',1)*size(H_MIMO_DCMA,2))*(2*size(H_MIMO_DCMA',2)-1)+numel(H_MIMO_DCMA'*H_MIMO_DCMA)+length(H_MIMO_DCMA'*H_MIMO_DCMA);
    Complexity_SD_DCMA = Complexity_SD_DCMA +2*size(H_MIMO_DCMA',1)^2*size(H_MIMO_DCMA',2)-size(H_MIMO_DCMA',1)^2+size(Q_DCMA,1);
    Complexity_SD_DCMA = Complexity_SD_DCMA +4/3*(length(Q_DCMA)^3);
    Complexity_SR_dcma =Complexity_SR_dcma +length(H_MIMO_DCMA'*H_MIMO_DCMA)^3+(size(H_MIMO_DCMA',1)*size(H_MIMO_DCMA,2))*(2*size(H_MIMO_DCMA',2)-1)+numel(H_MIMO_DCMA'*H_MIMO_DCMA)+length(H_MIMO_DCMA'*H_MIMO_DCMA);
    
end
BER_BEPD_SFSCMA=Err_BEPD_SFSCMA/(J*N_h*N_b*LM*I_CB);
BER_SEPD_SFSCMA=Err_SEPD_SFSCMA/(J*N_h*N_b*LM*I_CB);
BER_MPA_SFSCMA=Err_MPA_SFSCMA/(J*N_h*N_b*LM*I_CB);
BER_SR_BEP_SFSCMA = Err_SR_BEP_SFSCMA/(J*N_h*N_b*LM*I_CB);
BER_SR_SEP_SFSCMA = Err_SR_SEP_SFSCMA/(J*N_h*N_b*LM*I_CB);

BER_SD_DCMA=Err_SD_DCMA/(J*N_h*N_b*LM);
BER_BEPD_DCMA=Err_BEPD_DCMA/(J*N_h*N_b*LM);
BER_SR_DCMA=Err_SR_DCMA/(J*N_h*N_b*LM);


BER_MPA_SCMA=Err_MPA_SCMA/(J*N_h*N_b*LM);

Size_remind_SR_BEP_sfscma=Size_remind_SR_BEP_sfscma/(N_h*N_b);
Size_remind_SR_SEP_sfscma=Size_remind_SR_SEP_sfscma/(N_h*N_b);
Size_remind_SR_dcma=Size_remind_SR_dcma/(N_h*N_b);

%%%%%%%comlexity per information bit
Complexity_BEPD_SFSCMA_ave=Complexity_BEP_SFSCMA/(N_h*N_b*J*LM*I_CB);
Complexity_SEPD_SFSCMA_ave=Complexity_SEP_SFSCMA/(N_h*N_b*J*LM*I_CB);
Complexity_MPA_SFSCMA_ave=Complexity_MPA_SFSCMA/(N_h*N_b*J*LM*I_CB);
Complexity_SR_BEP_SFSCMA_ave=Complexity_SR_BEP_SFSCMA/(N_h*N_b*J*LM*I_CB);
Complexity_SR_SEP_SFSCMA_ave=Complexity_SR_SEP_SFSCMA/(N_h*N_b*J*LM*I_CB);

Complexity_BEPD_DCMA_ave=Complexity_BEPD_DCMA/(N_h*N_b*J*LM);
Complexity_SD_DCMA_ave=Complexity_SD_DCMA/(N_h*N_b*J*LM);
Complexity_SR_DCMA_ave=Complexity_SR_dcma/(N_h*N_b*J*LM);

Complexity_MPA_CSCMA_ave=Complexity_MPA_CSCMA/(N_h*N_b*J*LM);
%%%%%%%%%%%%%%%%%%%%output%%%%%%%%%%
BER_SF=[BER_BEPD_SFSCMA,BER_SEPD_SFSCMA,BER_MPA_SFSCMA,BER_SR_BEP_SFSCMA,BER_SR_SEP_SFSCMA];
BER_DCMA=[BER_BEPD_DCMA,BER_SD_DCMA,BER_SR_DCMA];
BER_CSCMA_MPA=BER_MPA_SCMA;
Size_remind=[Size_remind_SR_BEP_sfscma,Size_remind_SR_SEP_sfscma,Size_remind_SR_dcma];
Complexity_SF=[Complexity_BEPD_SFSCMA_ave,Complexity_SEPD_SFSCMA_ave,Complexity_MPA_SFSCMA_ave,Complexity_SR_BEP_SFSCMA_ave,Complexity_SR_SEP_SFSCMA_ave];
Complexity_DCMA=[Complexity_BEPD_DCMA_ave,Complexity_SD_DCMA_ave,Complexity_SR_DCMA_ave];
Complexity_SCMA=Complexity_MPA_CSCMA_ave;
end