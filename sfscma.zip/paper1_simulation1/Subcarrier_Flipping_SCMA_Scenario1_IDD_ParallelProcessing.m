%%% This program was written by Benyamin Haghniaz to simulate Subcarrier-Flip SCMA to achieve full
%%% Diversity in final rate 2 bits/timeslot
%%% This is the first scenario : SF-SCMA (Rate=2,16Bao), DCMA (Rate=2), SCMA (Rate=2,4Bao)
%%% IDD
%%% 4*6
%%% if S_IDD=0 , it means there is no iteration between detection and decoding
clc
clear;
close all;
warning off
LM =2;%%%bits per timeslot that is transmitted
S_SEP_sfscma = 2; %%%number of iterations in SEPD detector
S_IDD_sfscma = 1;%%%number of iterations in Iterative detection and decoding
S_IDD_dcma = 1;%%%number of iterations in Iterative detection and decoding
S_IDD_scma = 1;%%%number of iterations in Iterative detection and decoding

it_mpa_4Bao = 5;%%% number of iterations in original MPA
SNR = (4:14).';%;%%%SNR=Ec/N0
N_h = 100e1*[ones(size(SNR))]; %%% number of channel realization

tic
parfor ii=1:length(SNR)
    [BER_SF,BER_DCMA,BER_SCMA,Size_remind,Complexity_SF,Complexity_DCMA,Complexity_SCMA]=SimulatorScenario1_IDD(SNR(ii),N_h(ii),S_SEP_sfscma,S_IDD_sfscma,S_IDD_dcma,S_IDD_scma,it_mpa_4Bao);
    BER_SF_Final(ii,:)=BER_SF;
    BER_DCMA_Final(ii,:)=BER_DCMA;
    BER_SCMA_Final(ii,:)=BER_SCMA;
    Size_remind_Final(ii,:)=Size_remind;
    Complexity_SF_Final(ii,:)=Complexity_SF;
    Complexity_DCMA_Final(ii,:)=Complexity_DCMA;
    Complexity_SCMA_Final(ii,:)=Complexity_SCMA;
end
toc
%%
figure;
semilogy(SNR,BER_SF_Final(:,1),'--^r','LineWidth',1.5);
hold on
semilogy(SNR,BER_SF_Final(:,2),'--or','LineWidth',1.5);
hold on
semilogy(SNR,BER_DCMA_Final(:,1),'--ob','LineWidth',1.5);
hold on
semilogy(SNR,BER_SCMA_Final,'-->k','LineWidth',1.5);
legend('SF-SCMA, IDD-EPA','SF-SCMA, SISO SR-SD','DCMA, SISO STS-GSD','C-SCMA, IDD-MPA')
xlabel('SNR');ylabel('ABER');grid on;
figure
plot(SNR,Complexity_SF_Final(:,1),'--^r');hold on
plot(SNR,Complexity_SF_Final(:,2),'--or');hold on
plot(SNR,Complexity_DCMA_Final(:,1),'--ob');hold on
plot(SNR,Complexity_SCMA_Final,'-->k');hold on
xlabel('SNR');ylabel('Complexity per information bit');grid on;
legend('SF-SCMA, IDD-EPA','SF-SCMA, SISO SR-SD','DCMA, SISO STS-GSD','C-SCMA, IDD-MPA')
