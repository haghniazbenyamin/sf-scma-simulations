function [PxyPy,Pyx,Complexity]=MPA_detector_priori_corrected(y,X,H,F,K,J,M,Pi,Sigma,it_max,Timeslot)
%%%%matrix u is the messages that are sent from function nodes to variable nodes
%%%%matrix v is the messages that are sent from variable nodes to function nodes
Complexity=0;
u=zeros(Timeslot*K,J,M);
v=zeros(Timeslot*K,J,M);
Pyx=zeros(J,M);
%%%Note that we must send a message from a function node to a variable
%%%node for M possibility
%%initialization of u befor starting MPA
%%%this is just for starting computing
%%%%Pi (size J*M) is a matix of priori probabilities of codeword of each UEs
for m=1:M
    for j=1:J
        u(:,j,m)=F(:,j);
    end
end
%%starting MPA
for it=1:it_max
    %%in this part  we compute the messages that should be sent from variable nodes to function nodes in t_th iteration based on the messages that received from function nodes in t-1_th iteration
    for j=1:J
        aj=find(F(:,j)~=0);
        %         Complexity = Complexity + numel(F(:,j));
        t1=length(aj);
        for k=1:t1
            v(aj(k),j,:)=1;
            for l=1:t1
                if l==k
                    continue;
                else
                    v(aj(k),j,:)=v(aj(k),j,:).*u(aj(l),j,:);
                    Complexity = Complexity + (1/6)*numel(v(aj(k),j,:));
                end
            end
        end
    end
    %%%%%%%%%%%%%%
    for m=1:M
        for j=1:J
            v(:,j,m)=v(:,j,m)*Pi(j,m);
            %             Complexity = Complexity + size(v(:,j,m),1)*size(Pi(j,m),2)*(2*size(v(:,j,m),2)-1);
        end
    end
    %%%%In this subsection we nomalized the messgaes
    vp=sum(v,3);
%     Complexity = Complexity + numel(v);
    vz=find(vp==0);
    %     Complexity = Complexity + numel(vp);
    vp(vz)=1;
    for m=1:M
        v(:,:,m)=v(:,:,m)./vp;
        Complexity = Complexity  + (1/6)*numel(v(:,:,m));
    end
    %%In this part we compute the messages that should be sent from function nodes to variable nodes
    for k=1:K*Timeslot
        ak=find(F(k,:)~=0);
        %         Complexity = Complexity +size(F(k,:),2);
        t2=length(ak);
        t3=t2-1;
%         Complexity =  Complexity +1;
        tot=M^t3;
%         Complexity =  Complexity +abs(t3);
        sx=zeros(tot,t3);
        temp=1:tot;
        for i=1:t3
            d=rem(ceil((temp')/(tot/(M^i))),M);
%             Complexity = Complexity + length(temp)+length(temp)+i;
            for nloc=1:M
                num=rem(nloc,M);
%                 Complexity = Complexity + 1;
                loc=find(d==num);
                %                 Complexity = Complexity +length(d);
                sx(loc,i)=nloc;
            end
        end
        for j=1:t2
            u(k,ak(j),:)=0;
            sl=0;
            sxt=zeros(tot,1);
            vx=ones(tot,1);
            for i=1:t2
                if i==j
                    continue;
                else
                    sl=sl+1;
                    for h=1:tot
                        sxt(h)=sxt(h)+H(k,ak(i))*X(k,sx(h,sl),ak(i));%%%in this part , we compute all states transmitted symbols over the egdes other than the one which we want to transmit
                        Complexity = Complexity +size(H(k,ak(i)),1)*size(X(k,sx(h,sl),ak(i)),2)*(2*size(H(k,ak(i)),2)-1)+numel(sxt(h));
                        vx(h)=vx(h)*v(k,ak(i),sx(h,sl)); %%%in this part , we compute all messages that that received from variable nodes in last iteration
                        Complexity = Complexity +(1/6)*size(vx(h),1)*size(v(k,ak(i),sx(h,sl)),2)*(2*size(vx(h),2)-1);
                    end
                end
            end
            for h=1:tot
                for m=1:M
                    u(k,ak(j),m)=u(k,ak(j),m)+1/(pi*Sigma^2)*exp(-1/(Sigma^2)*(abs(y(k)-H(k,ak(j))*X(k,m,ak(j))-sxt(h)))^2)*vx(h);%%in this part we compute the messages that should be sent from function node to varaiable node
                    Complexity = Complexity + 1/2*numel(u(k,ak(j),m))+size(H(k,ak(j)),1)*size(X(k,m,ak(j)),2)*(2*size(H(k,ak(j)),2)-1)+2*numel(y(k))+(1+1/6)*numel(y(k));
                end
            end
        end
    end
    %%%%%%%%%%%%%%%
    %%%%In this subsection we nomalized the messages
    up=sum(u,3);
%     Complexity = Complexity + numel(u);
    uz=find(up==0);
    %     Complexity = Complexity + numel(up);
    up(uz)=1;
    for m=1:M
        u(:,:,m)=u(:,:,m)./up;
        Complexity = Complexity + (1/6)*numel(u(:,:,m));
    end
    if it==1
        for j=1:J
            loc=find(F(:,j)~=0);
            %             Complexity = Complexity +numel(F(:,j));
            for m=1:M
                Pyx(j,m)=prod(u(loc,j,m));
                Complexity = Complexity +(1/6)*numel(u(loc,j,m));
            end
        end
    end
end
%%%%here all iterations done
%%here we want to multiply all the messges that were received by each variable node to compute maximum  a posteriori probability of that varible node
PxyPy=zeros(J,M);
for j=1:J
    loc=find(F(:,j)~=0);
    %     Complexity = Complexity + numel(F(:,j));
    for m=1:M
        PxyPy(j,m)=prod(u(loc,j,m));
        Complexity = Complexity + (1/6)*numel(u(loc,j,m));
    end
    PxyPy(j,:)=PxyPy(j,:)/sum(PxyPy(j,:));
%     Complexity = Complexity +numel(PxyPy(j,:))*(1/6+1/2);
end
end