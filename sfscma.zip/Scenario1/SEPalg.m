function[qt,Mu_hat,Var_hat,Complexity]=SEPalg(CodeBooks,M,FactorGarph,N0,y,H,Nr,S_SEP,nturbo,pt)
%%%%This Program was written by Benyamin Haghniaz For his Phd Thesis
%%Scalar EP based on paper "Advanced NOMA receiver ... ",2021
%%%%matrix u is the messages that are sent from function nodes to variable nodes
%%%%matrix v is the messages that are sent from variable nodes to function nodes
%%%%H(:,:,Nr) is the total channel
Complexity = 0;
F = FactorGarph;
L=size(FactorGarph,1);
K=size(FactorGarph,2);
X=CodeBooks;
dk=numel(find(F(:,1)~=0));
dl=numel(find(F(1,:)~=0));
u_mean=-inf*ones(Nr*L,K);
u_var=-inf*ones(Nr*L,K);
Mu=-inf*ones(Nr*L,K);
Var=-inf*ones(Nr*L,K);
Z=-inf*ones(Nr*L,K);
V=-inf*ones(Nr*L,K);
Mu_hat=-inf*ones(L,K);
Var_hat=-inf*ones(L,K);
v_mean=-inf*ones(Nr*L,K);
v_var=-inf*ones(Nr*L,K);
if isempty(pt)
pt=ones(K,M)*(1/M);%%%initial priors
end
qt=pt;%%%initial posteriors
qt_aux =ones(K,M)*(1/M);
MAX=1e3;
MIN=1e-3;
Epsilon = 1e-16;
Minprob =1/realmax;
UnvalidUEs=1:K;
%% initialization of u befor starting EPA
for l=1:L
    Index1=find(F(l,:)~=0);
    for nr=1:Nr
        u_mean((nr-1)*L+l,Index1)=MIN;
        u_var((nr-1)*L+l,Index1)=MAX;
        v_mean((nr-1)*L+l,Index1)=MIN;
        v_var((nr-1)*L+l,Index1)=MAX;
        Mu((nr-1)*L+l,Index1)=MIN;
        Var((nr-1)*L+l,Index1)=MAX;
        Z((nr-1)*L+l,Index1)=MIN;
        V((nr-1)*L+l,Index1)=MAX;
    end
    Mu_hat(l,Index1)=0;
    Var_hat(l,Index1)=0;
end
%% starting EPA
for it=1:S_SEP
    
    for k=UnvalidUEs
        vk=find(F(:,k)~=0);
        for nr=1:Nr
            for ii=1:dk
                Mu(vk(ii)+(nr-1)*L,k)=qt(k,:)*((X(vk(ii),:,k)).');
                Complexity = Complexity + double(it~=1 || nturbo~=0)*(2*size(qt(k,:),2)-1);
                Var(vk(ii)+(nr-1)*L,k)=qt(k,:)*((abs(X(vk(ii),:,k)- Mu(vk(ii)+(nr-1)*L,k)).^2).');
                Complexity = Complexity + double(it~=1)*(2*numel(X(vk(ii),:,k)))+double(it~=1 || nturbo~=0)*(1/6*numel(qt(k,:))+1/2*(numel(qt(k,:))-1));
                Var(vk(ii)+(nr-1)*L,k)=real(Var(vk(ii)+(nr-1)*L,k));%real(Var(vk(ii)+(nr-1)*L,k));%real(Var(vk(ii)+(nr-1)*L,k));%max(real(Var(vk(ii)+(nr-1)*L,k)),Epsilon)
                v_var_aux =real(1/(1/Var(vk(ii)+(nr-1)*L,k)-1/u_var(vk(ii)+(nr-1)*L,k)));%max(real(1/(1/Var(vk(ii)+(nr-1)*L,k)-1/u_var(vk(ii)+(nr-1)*L,k))),Epsilon);%real(1/(1/Var(vk(ii)+(nr-1)*L,k)-1/u_var(vk(ii)+(nr-1)*L,k)))
                Complexity = Complexity + double(it~=1 || nturbo~=0)*(3/2+1);
                v_mean_aux = v_var_aux*( (Mu(vk(ii)+(nr-1)*L,k)/Var(vk(ii)+(nr-1)*L,k))-(u_mean(vk(ii)+(nr-1)*L,k) /u_var(vk(ii)+(nr-1)*L,k))+eps);
                Complexity = Complexity + double(it~=1 || nturbo~=0)*(3+1/6);
                if v_var_aux>0
                    v_var(vk(ii)+(nr-1)*L,k) = v_var_aux;
                    v_mean(vk(ii)+(nr-1)*L,k) = v_mean_aux;
                end
            end
        end
    end
    % HH=[H(:,:,1);H(:,:,2)];%%multiple antenna
    HH=H;%%single antenna
    for k=UnvalidUEs
        vk=find(F(:,k)~=0);
        for l=vk.'
            Fl=find(F(l,:)~=0);
            indexx=find(Fl~=k);
            Fl_aux=Fl(indexx);
            for nr=1:Nr
                % Z((nr-1)*L+l,k) =sum(v_mean((nr-1)*L+l,Fl_aux).*H((nr-1)*L+l,Fl_aux,nr));
                Z((nr-1)*L+l,k) =sum(v_mean((nr-1)*L+l,Fl_aux).*HH((nr-1)*L+l,Fl_aux));
                Complexity = Complexity + 2*length(Fl_aux)-1;
                % V((nr-1)*L+l,k) = sum(v_mean((nr-1)*L+l,Fl_aux).*(abs(H((nr-1)*L+l,Fl_aux,nr)).^2));
                V((nr-1)*L+l,k) = sum(v_var((nr-1)*L+l,Fl_aux).*(abs(HH((nr-1)*L+l,Fl_aux)).^2));%max( real(sum(v_var((nr-1)*L+l,Fl_aux).*(abs(HH((nr-1)*L+l,Fl_aux)).^2))),Epsilon );%sum(v_var((nr-1)*L+l,Fl_aux).*(abs(HH((nr-1)*L+l,Fl_aux)).^2))
                Complexity = Complexity + length(Fl_aux)+(length(Fl_aux))/6;
                u_mean((nr-1)*L+l,k)=(y(l,nr)-Z((nr-1)*L+l,k))/H(l,k,nr);
                Complexity = Complexity + 2;
                u_var((nr-1)*L+l,k)=real((N0+ V((nr-1)*L+l,k))/(abs(H(l,k,nr))^2));%max(real((N0+ V((nr-1)*L+l,k))/(abs(H(l,k,nr))^2)),Epsilon);
                Complexity = Complexity +(1/6+1/2);
            end
        end
    end
    Var_hat=zeros(size(Var_hat));Mu_hat=zeros(size(Mu_hat));
    for k=UnvalidUEs
        vk=find(F(:,k)~=0);
        for ii=1:dk
            for nr=1:Nr
                aa=1/u_var((nr-1)*L+vk(ii),k);
                Var_hat(vk(ii),k)=Var_hat(vk(ii),k)+aa;
            end
            Var_hat(vk(ii),k)=1/Var_hat(vk(ii),k);%max(1/Var_hat(vk(ii),k),Epsilon);
            Complexity = Complexity +1/6;
            for nr=1:Nr
                bb=u_mean((nr-1)*L+vk(ii),k)/u_var((nr-1)*L+vk(ii),k);
                Mu_hat(vk(ii),k)=Mu_hat(vk(ii),k)+bb;
            end
            Mu_hat(vk(ii),k)=Var_hat(vk(ii),k)*Mu_hat(vk(ii),k);
            Complexity = Complexity +1+(1/6+1/6);
        end
        for m=1:M
            qt(k,m)=pt(k,m)*exp(sum(max(-(abs(X(vk,m,k)- Mu_hat(vk,k)).^2)./Var_hat(vk,k),-100)));
            Complexity = Complexity +length(vk)*(1+1+1/6);
            if isnan(qt(k,m))
                disp('oops-SEP')
            end
        end
    end
    for k=UnvalidUEs
        if (sum(isfinite(qt(k,:)),2)==M) &&  (sum(qt(k,:))~=0) && ~isnan(any(qt(k,:)))
            qt(k,:) =max(qt(k,:),Minprob);
            qt(k,:) =(qt(k,:)/sum(qt(k,:)));
        else
            disp('no change - sep')
            qt(k,:) = qt_aux(k,:);
        end
    end
    qt_aux=qt;   
end
end