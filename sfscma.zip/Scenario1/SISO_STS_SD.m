% =========================================================================
% Title       : SISO Single Tree Search (STS) Sphere Decoder (SD)
% File        : SISO_STS_SD.m
% -------------------------------------------------------------------------
% Description :
%   Soft-input soft-output (SISO) single tree search (STS) sphere
%   decoder (SD) with extrinsic LLR clipping [Studer and Boelcskei, 2008].
%   This implementation bases on the following LLR definition:
%     L = log(Pr[x=+1]/Pr[x=-1])
%   where +1 corresponds to the null element in GF(2), i.e., the following
%   mapping is used:
%     0 -> +1
%     1 -> -1
% -------------------------------------------------------------------------
% Revisions   :
%   Date       Version  Author  Description
%   21-feb-07  1.4      studer  modified LLR definition
%   13-feb-07  1.3      studer  storage requirements minimized
%   05-feb-07  1.2      studer  ready for extrinsic output
%   16-jan-07  1.1      studer  leaf update and soft outputs added
%   28-sep-06  1.0      studer  file created: SD_const.m
% -------------------------------------------------------------------------
%   (C) 2006-2010 Communication Theory Group
%   ETH Zurich, 8092 Zurich, Switzerland
%   Author: Dr. Christoph Studer (e-mail: studerc@nari.ee.ethz.ch)
% =========================================================================

function [LLR_E1_data,complexity] = SISO_STS_SD(TxRx,R,y_hat,order,APP_LLR)

% ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% ++ invert LLR definition (adapt for your needs)
APP_LLR = - APP_LLR;
% ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
complexity=0;
% -- a priori information
APP_LLR_ordered = APP_LLR(order,:);
APP_bias = sum(abs(APP_LLR_ordered),2)'; % compute optimum max-log LLR bias

% -- initialization
Radius = inf;
PA = zeros(TxRx.Ntx,1); % path history
ST = zeros(TxRx.Ntx,length(TxRx.Constellations_norm)); % stack

% -- soft output specific
%   bin_array = mexde2bi([0:2^(TxRx.Modulation_order)-1],TxRx.Modulation_order);
bin_array = de2bi([0:2^(TxRx.Modulation_order)-1],TxRx.Modulation_order);
xML = inf*ones(TxRx.Ntx,TxRx.Modulation_order);         % ML hypothesis
lambdaML = inf;                                         % metric of ML hypothesis
lambdaMLBAR = inf*ones(TxRx.Ntx,TxRx.Modulation_order); % metric of counter hypotheses

% -- add root node to stack
Level = TxRx.Ntx;
APP_inc = 0.5*(APP_bias(Level)*ones(length(TxRx.Constellations_norm),1)-sign(0.5-bin_array)*APP_LLR_ordered(Level,:)');
ST(Level,:) = abs(y_hat(Level)-R(Level,Level)*TxRx.Constellations_norm.').^2+APP_inc;
complexity = complexity +(1+1+1)*length(TxRx.Constellations_norm);
%   complexity = 0; % we do not count the root node

% -- begin sphere decoder
while ( Level<=TxRx.Ntx )
    % -- find smallest PED in boundary
    [minPED,idx] = min( ST(Level,:) );

    % -- only proceed if list is not empty
    if minPED<inf
        ST(Level,idx) = inf; % mark child as tested
        NewPath = [ idx ; PA(Level+1:end,1) ]; % new best path

        % -- calculate current pruning radius
        Radius = 0;
        for lev = length(NewPath):-1:1 % rule for known bits
            Bits = bin_array(NewPath(lev)',:);
            for bit = 1:TxRx.Modulation_order
                if (Bits(bit)==xML(lev+TxRx.Ntx-length(NewPath),bit)) % ML-hypothesis
                    Radius = max(Radius,lambdaML);
                else % counter hypothesis (Bits~=xML)
                    if Bits(bit)==0 % (+1)
                        Radius = max(Radius,lambdaMLBAR(lev+TxRx.Ntx-length(NewPath),bit)-APP_LLR_ordered(lev+TxRx.Ntx-length(NewPath),bit));
                        complexity = complexity+1/2;
                    end
                    if Bits(bit)==1 % (-1)
                        Radius = max(Radius,lambdaMLBAR(lev+TxRx.Ntx-length(NewPath),bit)+APP_LLR_ordered(lev+TxRx.Ntx-length(NewPath),bit));
                        complexity = complexity+1/2;
                    end
                end
            end
        end
        for lev = 1:TxRx.Ntx-length(NewPath) % rule for unknown bits
            for bit = 1:TxRx.Modulation_order
                if xML(lev,bit)==0 % (+1)
                    Radius = max(Radius,lambdaMLBAR(lev,bit)+APP_LLR_ordered(lev,bit));
                    complexity = complexity+1/2;
                end
                if xML(lev,bit)==1 % (-1)
                    Radius = max(Radius,lambdaMLBAR(lev,bit)-APP_LLR_ordered(lev,bit));
                    complexity = complexity+1/2;
                end
            end
        end

        % -- search child
        if ( minPED<Radius )
            % -- valid candidate found
            %         complexity = complexity+1;
            if ( Level>1 )
                % -- expand this best node
                PA(Level:end,1) = NewPath;
                Level = Level-1; % downstep
                DF = R(Level,Level+1:end) * TxRx.Constellations_norm(PA(Level+1:end,1)).';
                complexity = complexity + 2*size(R(Level,Level+1:end),2)-1;
                APP_inc = 0.5*(APP_bias(Level)*ones(length(TxRx.Constellations_norm),1)-sign(0.5-bin_array)*APP_LLR_ordered(Level,:)');
                complexity = complexity +1/2* length(TxRx.Constellations_norm)+size(bin_array,1)*size(APP_LLR_ordered(Level,:)',2)*(1/6*size(bin_array,2)+1/2*size(bin_array,2)-1);
                ST(Level,:) = minPED + abs(y_hat(Level)-R(Level,Level)*TxRx.Constellations_norm.'-DF).^2+APP_inc;
                complexity = complexity+(1+1+1+1)*length(TxRx.Constellations_norm);
            else
                % -- valid leaf found
                x = bin_array(NewPath',:);
                % -- update hypotheses and clip LLRs
                if minPED<lambdaML % case 1)
                    for lev=1:TxRx.Ntx
                        for bit=1:TxRx.Modulation_order
                            if x(lev,bit)~=xML(lev,bit)
                                if xML(lev,bit)==0 % (+1)
                                    lambdaMLBAR(lev,bit) = lambdaML+APP_LLR_ordered(lev,bit);
                                    complexity = complexity +1/2;
                                end
                                if xML(lev,bit)==1 % (-1)
                                    lambdaMLBAR(lev,bit) = lambdaML-APP_LLR_ordered(lev,bit);
                                    complexity = complexity +1/2;
                                end

                            end
                        end
                    end
                    lambdaML = minPED; % update ML metric
                    xML = x;           % update ML hypothesis
                    % -- clipping (corrrected)
                    switch (TxRx.Detector.Clipping)
                      case 'exact', % -- yields prefectly clipped LLRs
                        for lev=1:TxRx.Ntx
                          for bit=1:TxRx.Modulation_order
                            lambdaMLBAR(lev,bit) = max(lambdaML-TxRx.Detector.MaxLLR,min(lambdaMLBAR(lev,bit),lambdaML+TxRx.Detector.MaxLLR));
                          end
                        end
                      case 'legacy', % -- low-complexity approximation
                        for lev=1:TxRx.Ntx
                          for bit=1:TxRx.Modulation_order
                            lambdaMLBAR(lev,bit) = min(lambdaMLBAR(lev,bit),lambdaML+TxRx.Detector.MaxLLR);
                          end
                        end
                      otherwise,
                        error('No valid TxRx.Detector.Clipping in SISO_STS_SD.m')
                    end
                else % case 2)
                    for lev=1:TxRx.Ntx
                        for bit=1:TxRx.Modulation_order
                            if (xML(lev,bit)~=x(lev,bit))
                                if (xML(lev,bit)==0)&(minPED-APP_LLR_ordered(lev,bit)<lambdaMLBAR(lev,bit))
                                    lambdaMLBAR(lev,bit) = minPED-APP_LLR_ordered(lev,bit);
                                    complexity = complexity +1/2;
                                end
                                if (xML(lev,bit)==1)&(minPED+APP_LLR_ordered(lev,bit)<lambdaMLBAR(lev,bit))
                                    lambdaMLBAR(lev,bit) = minPED+APP_LLR_ordered(lev,bit);
                                    complexity = complexity +1/2;
                                end
                            end
                        end
                    end
                end
                % -- end
            end
        end
    else
        % -no more childs to be checked
        Level=Level+1;
    end
end

% -- compute soft outputs and reorder LLRs
bin_array_coded = sign(0.5-xML).*(lambdaMLBAR-lambdaML);
complexity = complexity +(1/2+1/6)*numel(bin_array_coded);
% -- if early termination happens, additional clipping might be required
bin_array_coded = max(min(bin_array_coded,TxRx.Detector.MaxLLR),-TxRx.Detector.MaxLLR);
LLR_E1_data(order',:) = bin_array_coded;
% ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% ++ invert LLR definition
LLR_E1_data = - LLR_E1_data;
% ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

return