% =========================================================================
% Title       : Preprocessing for Tree-Search-based MIMO Detectors
% File        : preprocessing.m
% -------------------------------------------------------------------------
% Description :
%   Implements standard QR-decomposition (QRD), sorted QRD (SQRD), and 
%   regularized SQRD according to the MMSE criterion.  
% ------------------------------------------------------------------------- 
% Revisions   :
%   Date       Version  Author  Description
%   29-may-06  1.0      studer  initial version (adapted from ofdm_sim)
% -------------------------------------------------------------------------
%   (C) 2006-2010 Communication Theory Group                      
%   ETH Zurich, 8092 Zurich, Switzerland                               
%   Author: Dr. Christoph Studer (e-mail: studerc@nari.ee.ethz.ch)     
% =========================================================================
% -------------------------------------------------------------------------
% -- Sorted QR Decomposition [Wuebben et al., 2003]
% -------------------------------------------------------------------------
function [Qa,R,order] = sqr(H)
  N_tx = size(H,2); % # TX
  N_rx = size(H,1); % # RX
  Q=H;
  R=zeros(N_tx);
  P=eye(N_tx);
  for i=[1:N_tx]
    s=diag(Q(:,i:N_tx)'*Q(:,i:N_tx));
    [p,idx]=min(s); idx=idx+i-1;
    tmp=Q(:,i); Q(:,i)=Q(:,idx); Q(:,idx)=tmp;
    tmp=P(:,i); P(:,i)=P(:,idx); P(:,idx)=tmp;
    tmp=R(:,i); R(:,i)=R(:,idx); R(:,idx)=tmp;
    R(i,i)=sqrt(s(idx-i+1));
    Q(:,i)=Q(:,i)/R(i,i);
    for k=[i+1:N_tx]
      R(i,k)=Q(:,i)'*Q(:,k);
      Q(:,k)=Q(:,k)-R(i,k)*Q(:,i);
    end
  end
  Qa    = Q(1:N_rx,1:N_tx); % extract upper left part only
  R     = R(1:N_tx,:);      % extract upper half only (lower half is zero)
  order = [1:N_tx]*P;
return
