%%% This program was written by Benyamin Haghniaz to simulate Subcarrier-Flip SCMA to achieve full
%%% Diversity in final uncoded rate 1 bits/timeslot
%%% 4*6
%%% This is the first scenario : SF-SCMA(4Bao), DCMA(Rate=1), C-SCMA(Rate=1)
%%% IDD
clc
clear;
close all;
warning off
it_mpa_Total = 5;%%% number of iterations in Total-MPA
it_mpa_2Bao = 3;%%% number of iterations in original MPA
S_BEP_dcma=1; %%%number of iterations in BEPD detector
S_SEP_sfscma =1; %%%number of iterations in SEPD detector
S_IDD_sfscma=2;%%%number of iterations in Iterative detection and decoding
S_IDD_dcma=2;%%%number of iterations in Iterative detection and decoding
S_IDD_scma=2;%%%number of iterations in Iterative detection and decoding

LM =1;%%bits per timeslot that is transmitted
SNR =(0:1:11).';%%%SNR=Ec/N0
N_h = 100e3*ones(size(SNR)); %%% number of channel realization
tic
parfor ii=1:length(SNR)
    [BER_SF,BER_DCMA,BER_CSCMA_MPA,Size_remind,Complexity_SF,Complexity_DCMA,Complexity_SCMA]=SimulatorScenario0_IDD(SNR(ii),N_h(ii),S_SEP_sfscma,S_BEP_dcma,S_IDD_sfscma,S_IDD_dcma,S_IDD_scma,it_mpa_Total,it_mpa_2Bao);
    BER_SF_Final(ii,:)=BER_SF;
    BER_DCMA_Final(ii,:)=BER_DCMA;
    BER_SCMA_Final(ii,:)=BER_CSCMA_MPA;
    Size_remind_Final(ii,:)=Size_remind;
    Complexity_SF_Final(ii,:)=Complexity_SF;
    Complexity_DCMA_Final(ii,:)=Complexity_DCMA;
    Complexity_SCMA_Final(ii,:)=Complexity_SCMA;
end
toc
%%
figure;
semilogy(SNR,BER_SF_Final(:,1),'--^r','LineWidth',2);
hold on
semilogy(SNR,BER_SF_Final(:,2),'--or','LineWidth',2);
hold on
semilogy(SNR,BER_DCMA_Final(:,1),'--^b','LineWidth',2);
hold on
semilogy(SNR,BER_DCMA_Final(:,2),'--ob','LineWidth',2);
hold on
semilogy(SNR,BER_SCMA_Final,'-->k','LineWidth',2);
legend('SF-SCMA, IDD-EPA','sf-SCMA, SISO SR-SD','DCMA, SISO PBEP','DCMA, SISO STS-GSD','c-SCMA, IDD-MPA')
xlabel('SNR(dB)');ylabel('ABER');grid on;
figure
plot(SNR,Complexity_SF_Final(:,1),'--^r','LineWidth',2);hold on
plot(SNR,Complexity_SF_Final(:,2),'--or','LineWidth',2);hold on
plot(SNR,Complexity_DCMA_Final(:,1),'--^b','LineWidth',2);hold on
plot(SNR,Complexity_DCMA_Final(:,2),'--ob','LineWidth',2);hold on
xlabel('SNR(dB)');ylabel('Complexity');grid on;
legend('SF-SCMA, IDD-EPA','sf-SCMA, SISO SR-SD','DCMA, SISO PBEP','DCMA, SISO STS-GSD')